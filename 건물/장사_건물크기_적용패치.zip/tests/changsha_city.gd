extends SceneTree
const Scene = preload("res://main.tscn")
const Space = preload("res://world/changsha/space.gd")
const INPUTS = [["f_down"],["f_left","f_down"],["f_left"],["f_left","f_up"],["f_up"],["f_right","f_up"],["f_right"],["f_right","f_down"]]
var scene
var checks: int = 0
var failures: int = 0
func _initialize() -> void: call_deferred("run")
func check(value: bool, label: String) -> void:
 checks += 1
 if not value:
  failures += 1
  push_error("CHANGSHA: " + label)
func tick(count: int = 1) -> void:
 for i in range(count):
  await physics_frame
  await process_frame
func release() -> void:
 for action in ["f_left","f_right","f_up","f_down"]: Input.action_release(action)
func point_input(direction: Vector2) -> void:
 release()
 var v: Vector2 = Space.project(direction).normalized()
 Input.action_press("f_left",maxf(0,-v.x))
 Input.action_press("f_right",maxf(0,v.x))
 Input.action_press("f_up",maxf(0,-v.y))
 Input.action_press("f_down",maxf(0,v.y))
func key(code: int) -> void:
 var event := InputEventKey.new()
 event.pressed = true
 event.physical_keycode = code
 Input.parse_input_event(event)
 Input.flush_buffered_events()
 await tick()
func walk(target: Vector2) -> bool:
 for i in range(2200):
  var remaining: Vector2 = target - scene.actor.logical
  if remaining.length() < 0.12:
   release()
   await tick(2)
   return true
  point_input(remaining)
  await tick()
 release()
 return false
func capture(name: String) -> void:
 await tick(6)
 await RenderingServer.frame_post_draw
 var destination: String = OS.get_environment("CHANGSHA_CAPTURE_DIR").path_join(name+".png")
 check(root.get_texture().get_image().save_png(destination)==OK,"capture "+name)
func blocked(point: Vector2) -> bool:
 var query := PhysicsPointQueryParameters2D.new()
 query.position = Space.project(point)
 query.collision_mask = 1
 return not scene.get_world_2d().direct_space_state.intersect_point(query).is_empty()
func size_gallery() -> void:
 var overlay := CanvasLayer.new()
 overlay.layer = 100
 root.add_child(overlay)
 var background := ColorRect.new()
 background.color = Color("ded9ca")
 background.size = Vector2(1920,1080)
 overlay.add_child(background)
 var keys = ["rustic1","house","bright_house","warehouse","twohouse","inn","shop","bookshop","hall","government","martial","workshop"]
 var sizes: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://world/changsha/building-size-standard.json"))
 var header := Label.new()
 header.text = "민가_1 기준 크기 비교 · 모든 칸 동일한 축소 배율 · 도원 크기 유지"
 header.position = Vector2(35,16)
 header.add_theme_font_override("font",scene.font)
 header.add_theme_font_size_override("font_size",26)
 header.add_theme_color_override("font_color",Color("28382e"))
 overlay.add_child(header)
 for i in range(keys.size()):
  var art: Dictionary = scene.catalog[keys[i]]
  var baseline := Vector2(190+(i%4)*480,300+(i/4)*330)
  var sprite := Sprite2D.new()
  sprite.texture = load(art.texture)
  sprite.centered = false
  sprite.scale = Vector2.ONE*art.display_scale*0.42
  sprite.position = baseline-Vector2(art.anchor[0],art.anchor[1])*sprite.scale
  overlay.add_child(sprite)
  var label := Label.new()
  label.text = str(sizes.assets[keys[i]].sources[0]).get_file().get_basename()+" · x%.3f" % art.display_scale
  label.position = Vector2((i%4)*480+15,baseline.y+18)
  label.add_theme_font_override("font",scene.font)
  label.add_theme_font_size_override("font_size",21)
  label.add_theme_color_override("font_color",Color("28382e"))
  overlay.add_child(label)
  var player := Sprite2D.new()
  player.texture = scene.actor.idle_textures[0]
  player.centered = false
  player.scale = Vector2.ONE*float(scene.actor.standard.display_scale)*0.42
  player.position = baseline+Vector2(175,0)-Vector2(scene.actor.standard.anchor[0],scene.actor.standard.anchor[1])*player.scale
  overlay.add_child(player)
 await capture("building-scale-comparison")
 overlay.queue_free()
func run() -> void:
 root.content_scale_size = Vector2i(1920,1080)
 root.size = Vector2i(1920,1080)
 scene = Scene.instantiate()
 root.add_child(scene)
 current_scene = scene
 await tick(5)
 check(scene.buildings.size()==74,"66 buildings and eight stalls loaded in actual main scene")
 check(scene.plan.map_size==[160.0,140.0],"planned total size")
 check(scene.actor.speed==9.6 and scene.actor.sprite.material==null,"doubled city player speed and no breathing")
 check(scene.camera.is_current() and is_equal_approx(scene.camera.zoom.x,0.85),"original default camera scale")
 for point in [Vector2.ZERO,Vector2(81,64),Vector2(160,140)]:check(Space.unproject(Space.project(point)).is_equal_approx(point),"city projection invertible")
 for b in scene.buildings:
  check(b.plot.grow(0.001).encloses(b.footprint),b.entry.id+" footprint inside reserved plot")
  check(is_equal_approx(b.sprite.scale.x,b.sprite.scale.y) and is_zero_approx(b.sprite.rotation),b.entry.id+" no image distortion")
  check(b.sprite.texture!=null,b.entry.id+" PNG resource loaded")
  var front: Dictionary = scene.catalog[b.entry.asset]
  check(is_equal_approx(b.uniform_scale,front.display_scale),b.entry.id+" uses fixed asset scale instead of plot fit")
  for other in scene.buildings:
   if other==b:continue
   check(not b.footprint.grow(-0.01).intersects(other.footprint.grow(-0.01)),b.entry.id+" independent collision")
   check(not other.footprint.grow(0.18).has_point(b.approach),b.entry.id+" reachable outside other footprints")
 var families: Dictionary = {}
 var rows: Dictionary = {}
 var back_count: int = 0
 for b in scene.buildings:
  var art: Dictionary = scene.catalog[b.entry.asset]
  families[art.family]=true
  if b.entry.view == "back": back_count+=1
  check((b.entry.view=="back") == (b.facing=="north"),b.entry.id+" view and hidden entrance face street")
  check(art.view==b.entry.view,b.entry.id+" correct front or rear resource")
  var anchor := Vector2(b.door.x,b.entry.road_anchor[1])
  check(signf(anchor.y-b.door.y)==(-1.0 if b.facing=="north" else 1.0),b.entry.id+" entrance points toward its street")
  for other in scene.buildings:
   if other==b:continue
   var access := Rect2(Vector2(b.door.x-0.18,minf(b.door.y,anchor.y)-0.01),Vector2(0.36,absf(b.door.y-anchor.y)+0.02))
   check(not access.intersects(other.footprint),b.entry.id+" entrance connection clear")
  for road in scene.plan.roads:
   check(not b.footprint.intersects(scene.road_rect(road)),b.entry.id+" does not occupy public road")
  if not rows.has(b.entry.row_id):rows[b.entry.row_id]=[]
  rows[b.entry.row_id].append(art.family)
 check(families.size()>=15 and back_count==0,"varied assets without facing rows")
 for sequence in rows.values():
  for i in range(2,sequence.size()):check(not(sequence[i]==sequence[i-1] and sequence[i]==sequence[i-2]),"same facade repeated at most twice in row")
 check(scene.gate_records.size()==6,"four city gates plus two private entrances")
 for b in scene.buildings:
  check(scene.plan.zone_assets[b.entry.zone].has(b.entry.asset),b.entry.id+" belongs to district asset palette")
  if b.entry.zone.begins_with("housing"):
   check(b.entry.asset in ["house","rustic1","rustic2","twohouse","bright_house"],"residential district contains only house assets")
  if b.entry.zone=="market":
   check(b.entry.asset in ["shop","bookshop","teahouse","silk","inn","vegetable","general"],"market contains only commercial assets")
  if b.entry.zone=="martial":check(b.entry.asset in ["martial","hall"],"martial buildings remain in their own compound")
  if b.entry.zone=="workshop":check(b.entry.asset in ["workshop","warehouse2"],"craft district contains workshops and material stores")
  for barrier in scene.barriers:
   for rect in barrier.rects:check(not rect.intersects(b.footprint),b.entry.id+" does not intersect enclosure")
 for run in scene.wall_runs:
  var steps := ceili(run.a.distance_to(run.b)/0.2)
  for i in range(steps+1):check(blocked(run.a.lerp(run.b,float(i)/steps)),run.owner+" connected collision along entire wall")
 for gate in scene.gate_records:
  check(not blocked(gate.center),gate.owner+" opening has no invisible blocker")
  check(blocked(gate.center+gate.axis*(gate.clear+gate.post)/2),gate.owner+" gate support collides")
 var barrier_art: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://world/changsha/barrier-catalog.json"))
 for part in scene.barriers:
  if part.enclosure_id!="city":continue
  var art: Dictionary = barrier_art["city_gate" if part.part=="gate" else "city_b"]
  var first: Vector2
  var second: Vector2
  if part.part=="gate":
   first = Vector2(art.anchor[0]-art.span/2,art.anchor[1]-art.foot_rise/2)
   second = Vector2(art.anchor[0]+art.span/2,art.anchor[1]+art.foot_rise/2)
  else:
   first = Vector2(art.anchor[0],art.anchor[1])
   second = first+Vector2(art.span,tan(deg_to_rad(art.angle))*art.span)
  if part.sprite.flip_h:
   first.x=part.sprite.texture.get_width()-first.x
   second.x=part.sprite.texture.get_width()-second.x
  var line: Vector2 = part.sprite.to_global(second)-part.sprite.to_global(first)
  var expected: Vector2 = Space.A if is_equal_approx(part.start.y,part.finish.y) else Space.B
  check(is_equal_approx(line.y/line.x,expected.y/expected.x),"city wall/gate artwork base follows exact field axis")
  var t: Transform2D = part.sprite.transform
  check(is_zero_approx(t.y.x) and is_equal_approx(t.x.x,t.y.y),"city columns remain upright with unchanged vertical/horizontal pixel scale")
  check(((part.sprite.to_global(first)+part.sprite.to_global(second))/2).distance_to(part.position)<0.01,"city artwork base center stays on logical collision")
 var reference_sizes: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://world/changsha/building-size-standard.json"))
 check(is_equal_approx(scene.catalog.rustic1.front_span_px*scene.catalog.rustic1.display_scale/64.0,5.2),"house_1 reference frontage remains 5.2 tiles")
 for family in reference_sizes.assets:
  if not scene.catalog.has(family):continue
  var first = scene.Building.new()
  var second = scene.Building.new()
  var info = {"id":"memory","name":"memory","bounds":[0,0,8,8],"asset":family,"facing":"south"}
  first.setup(info,scene.catalog[family])
  info = info.duplicate(true)
  info.bounds=[0,0,80,80]
  second.setup(info,scene.catalog[family])
  check(is_equal_approx(first.uniform_scale,second.uniform_scale) and first.footprint.size.is_equal_approx(second.footprint.size),family+" plot enlargement never enlarges asset or collision")
  var back = scene.Building.new()
  back.setup(info,scene.catalog[family+"_back"])
  check(back.footprint.size.is_equal_approx(first.footprint.size),family+" front and rear share physical size")
  first.free()
  second.free()
  back.free()
 if "--size-capture" in OS.get_cmdline_user_args():
  scene.review_jump(5)
  await capture("market")
  scene.review_jump(7)
  await capture("housing")
  await size_gallery()
 elif "--wall-angle-capture" in OS.get_cmdline_user_args():
  scene.actor.set_logical(Vector2(81,18))
  await capture("city-gate")
  scene.actor.set_logical(Vector2(35,16))
  await capture("city-corner")
 elif "--capture" in OS.get_cmdline_user_args():
  for i in [5,6,9]:
   scene.review_jump(i)
   await capture("market" if i==5 else "martial" if i==6 else "farm")
  scene.actor.set_logical(Vector2(81,18))
  await capture("city-gate")
  scene.actor.set_logical(Vector2(35,16))
  await capture("city-corner")
  await key(KEY_M)
  await capture("city-map")
 else:
  # Compare real screen displacement in unobstructed ground, including diagonal input.
  var lengths: Array[float] = []
  for inputs in INPUTS:
   scene.actor.set_logical(Vector2(145,9))
   await tick(2)
   var start: Vector2 = scene.actor.position
   for action in inputs: Input.action_press(action)
   await tick(12)
   release()
   lengths.append(scene.actor.position.distance_to(start))
   await tick(2)
  check(lengths.min()>100 and lengths.max()-lengths.min()<0.1,"actual horizontal vertical and diagonal screen speeds match")
  # Actual eight-direction walking and stop transitions on the central road crossing.
  for direction in range(8):
   scene.actor.set_logical(Vector2(81,64))
   var frames: Dictionary = {}
   for action in INPUTS[direction]:Input.action_press(action)
   for i in range(55):
    await tick()
    frames[scene.actor.displayed_frame]=true
   release()
   check(scene.actor.direction_index==direction,"input direction "+str(direction))
   check(frames.size()==8,"all eight frames "+str(direction))
   await tick(2)
   check(not scene.actor.moving and scene.actor.sprite.texture==scene.actor.idle_textures[direction],"matching idle "+str(direction))
  # Traverse the main roads with real physics, not teleports across buildings.
  scene.actor.set_logical(Vector2(30,64))
  check(await walk(Vector2(154,64)),"west quay to eastern farmland along main road")
  scene.actor.set_logical(Vector2(81,15))
  check(await walk(Vector2(81,121)),"north to south central avenue")
  for y in [26,39,52,77,90,112,125]:
   scene.actor.set_logical(Vector2(37,y))
   check(await walk(Vector2(78,y)),"west district public street at "+str(y))
  for y in [27,40,55,110,124]:
   scene.actor.set_logical(Vector2(84,y))
   check(await walk(Vector2(123,y)),"east district public street at "+str(y))
  for gate in scene.gate_records:
   var center: Vector2 = gate.center
   var axis: Vector2 = gate.axis
   var normal := Vector2(-axis.y,axis.x)
   scene.actor.set_logical(center-normal*1.6)
   check(await walk(center+normal*1.6),gate.owner+" gate actually passable forward")
   check(await walk(center-normal*1.6),gate.owner+" gate actually passable backward")
  var sides_checked: Dictionary = {}
  for run in scene.wall_runs:
   var axis: Vector2 = (run.b-run.a).normalized()
   var key: String = str(run.owner)+str(axis)+str(run.a.y if axis.x else run.a.x)
   if sides_checked.has(key):continue
   sides_checked[key]=true
   var middle: Vector2 = (run.a+run.b)/2
   var normal := Vector2(-axis.y,axis.x)
   scene.actor.set_logical(middle-normal*1.2)
   point_input(normal)
   await tick(24)
   release()
   check((scene.actor.logical-middle).dot(normal)<-0.05,run.owner+" physical wall blocks crossing")
  for b in scene.buildings:
   if not b.entry.id in ["W01","C01","I01","M01","G01","T01","S01"]:continue
   scene.actor.set_logical(Vector2(b.door.x,b.door.y+1.0))
   await tick(2)
   point_input(Vector2(0,-1))
   await tick(30)
   release()
   check(not b.footprint.grow(-0.01).has_point(scene.actor.logical),b.entry.id+" building blocks entry")
  scene.actor.set_logical(Vector2(22.5,64))
  point_input(Vector2(-1,0))
  await tick(30)
  release()
  check(scene.actor.logical.x>=22.29,"river boundary cannot be crossed")
  scene.review_jump(5)
  var previous: Vector2 = scene.actor.logical
  await key(KEY_M)
  check(scene.map_panel.visible and not scene.actor.is_physics_processing(),"map pauses movement")
  Input.action_press("f_down")
  await tick(5)
  release()
  check(scene.actor.logical==previous,"map input does not move player")
  await key(KEY_M)
  check(not scene.map_panel.visible and scene.actor.is_physics_processing(),"closing map restores movement")
  await key(KEY_M)
  await key(KEY_ESCAPE)
  check(not scene.map_panel.visible,"Esc closes map too")
  var map_button: Button = scene.notice.get_parent().get_child(3)
  map_button.pressed.emit()
  check(scene.map_panel.visible,"visible map button opens same map")
  await key(KEY_M)
  check(not scene.map_panel.visible,"M closes map opened by button")
  await key(KEY_0)
  check(scene.actor.logical.distance_to(scene.REVIEW_POINTS[9])<0.01,"review shortcut to farmland")
  var event := InputEventMouseButton.new()
  event.button_index=MOUSE_BUTTON_WHEEL_UP
  event.pressed=true
  Input.parse_input_event(event)
  Input.flush_buffered_events()
  await tick(3)
  check(is_equal_approx(scene.camera.zoom_factor,1.1),"actual wheel changes city zoom")
  await key(KEY_C)
  await tick(70)
  check(is_equal_approx(scene.camera.displayed_factor,1.0),"C restores original zoom")
  for i in range(10):
   scene.review_jump(i)
   await tick(2)
   var collision: KinematicCollision2D = scene.actor.move_and_collide(Vector2.ZERO,true)
   check(collision==null,"review position "+str(i)+" unoccupied")
  var target = scene.buildings.filter(func(b): return b.entry.id == "M01")[0]
  scene.actor.set_logical(target.approach)
  await tick(2)
  await key(KEY_F)
  check(scene.notice.text.contains("후속 작업"),"facility notice explains deferred interior")
  await key(KEY_M)
  var old = weakref(scene)
  await key(KEY_F2)
  await tick(4)
  scene = current_scene
  check(old.get_ref()==null,"leaving city frees its actor and scene")
  check(scene.seamless != null and scene.actor.is_physics_processing(),"F2 opens preserved seamless test without paused input")
  check(InputMap.has_action("f_left"),"destination input remains registered")
 release()
 scene.queue_free()
 await process_frame
 check(not InputMap.has_action("f_left"),"scene input cleanup")
 print("CHANGSHA: %s (%d checks, %d failures)" % ["PASS" if failures==0 else "FAIL",checks,failures])
 quit(0 if failures==0 else 1)
