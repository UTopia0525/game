extends Node2D
const Space = preload("res://world/changsha/space.gd")
const Player = preload("res://world/changsha/actor.gd")
const Building = preload("res://world/changsha/building.gd")
const Ground = preload("res://world/changsha/ground.gd")
const Camera = preload("res://world/changsha/camera.gd")
const Barrier = preload("res://world/changsha/barrier.gd")
const MapView = preload("res://world/changsha/map.gd")
const REVIEW_POINTS = [Vector2(30,64),Vector2(54,26),Vector2(99,27),Vector2(55,52),Vector2(101,55),Vector2(54,77),Vector2(99,99),Vector2(55,112),Vector2(102,110),Vector2(145,42)]
var plan: Dictionary
var catalog: Dictionary
var actor
var camera
var depth_root: Node2D
var buildings: Array = []
var barriers: Array = []
var occluders: Array = []
var wall_runs: Array = []
var gate_records: Array = []
var static_order: Array = []
var registered_inputs: Array = []
var title: Label
var status: Label
var notice: Label
var help_panel: PanelContainer
var map_panel: PanelContainer
var map_view
var labels: Array = []
var show_labels: bool = true
var nearest
var info_text: String = ""
var info_for_id: String = ""
var font: Font

func _ready() -> void:
 plan = JSON.parse_string(FileAccess.get_file_as_string("res://world/changsha/layout.json"))
 catalog = JSON.parse_string(FileAccess.get_file_as_string("res://world/changsha/catalog.json"))
 var sizes: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://world/changsha/building-size-standard.json"))
 for key in catalog:
  var art: Dictionary = catalog[key]
  var front: Dictionary = catalog[art.family]
  var scale_value: float = sizes.assets[art.family].front_scale
  art["display_scale"] = scale_value*float(front.front_span_px)/float(art.front_span_px)
  art["footprint_tiles"] = [float(front.front_span_px)*scale_value/64.0,float(front.depth_span_px)*scale_value/64.0]
 font = load("res://assets/fonts/NanumMyeongjo-Regular.ttf")
 _register_inputs()
 RenderingServer.set_default_clear_color(Color("899d82"))
 _build_ground()
 depth_root = Node2D.new()
 add_child(depth_root)
 for entry in plan.buildings:
  var b = Building.new()
  b.setup(entry, catalog[entry.asset])
  depth_root.add_child(b)
  buildings.append(b)
  var label := Label.new()
  label.text = entry.name
  label.add_theme_font_override("font",font)
  label.add_theme_font_size_override("font_size",17)
  label.add_theme_color_override("font_color",Color("f5ecd7"))
  label.add_theme_color_override("font_shadow_color",Color("24342a"))
  label.add_theme_constant_override("shadow_offset_x",1)
  label.add_theme_constant_override("shadow_offset_y",2)
  label.position = Space.project(b.approach) - b.position + Vector2(-50,12)
  label.mouse_filter = Control.MOUSE_FILTER_IGNORE
  b.add_child(label)
  labels.append(label)
 _build_enclosures()
 occluders = buildings+barriers
 _order_buildings()
 actor = Player.new()
 var art: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://prototypes/f_style_trial/art.json"))
 actor.setup(art)
 depth_root.add_child(actor)
 actor.movement_bounds = Rect2(22.3,0.3,137.4,139.4)
 actor.set_logical(Vector2(plan.spawn[0],plan.spawn[1]))
 _add_water_collision()
 camera = Camera.new()
 camera.setup(actor)
 add_child(camera)
 _build_hud()

func _register_inputs() -> void:
 var keys = {"f_left":[KEY_A,KEY_LEFT],"f_right":[KEY_D,KEY_RIGHT],"f_up":[KEY_W,KEY_UP],"f_down":[KEY_S,KEY_DOWN]}
 for action in keys:
  if InputMap.has_action(action): continue
  InputMap.add_action(action)
  registered_inputs.append(action)
  for key in keys[action]:
   var event := InputEventKey.new()
   event.physical_keycode = key
   InputMap.action_add_event(action,event)

func road_rect(road: Dictionary) -> Rect2:
 var a := Vector2(road.a[0],road.a[1])
 var b := Vector2(road.b[0],road.b[1])
 var width: float = road.width
 return Rect2(Vector2(a.x-width/2,minf(a.y,b.y)),Vector2(width,absf(b.y-a.y))) if a.x == b.x else Rect2(Vector2(minf(a.x,b.x),a.y-width/2),Vector2(absf(b.x-a.x),width))

func ground_kind(point: Vector2) -> String:
 if point.x < 22: return "water"
 var bounds: Array = plan.city_bounds
 var inside: bool = Rect2(bounds[0],bounds[1],bounds[2],bounds[3]).has_point(point)
 for road in plan.roads:
  if road_rect(road).has_point(point): return "paving" if inside else "dirt"
 if Rect2(23,38,9,52).has_point(point): return "wood"
 for area in plan.ground_areas:
  var b: Array = area.bounds
  if Rect2(b[0],b[1],b[2],b[3]).has_point(point):return area.terrain
 if inside: return "stone"
 if Rect2(140,47,14,12).has_point(point) or Rect2(140,90,14,28).has_point(point): return "field"
 return "grass"

func _build_ground() -> void:
 var textures: Dictionary = {}
 for key in ["grass","earth","dirt","stone","paving","water","wood","field"]:
  textures[key] = load("res://assets/cities/changsha/terrain/%s.png" % key)
 for x in range(0,160,16):
  for y in range(0,140,16):
   var chunk = Ground.new()
   chunk.origin = Space.project(Vector2(x,y))
   chunk.position = chunk.origin
   chunk.textures = textures
   for u in range(x,mini(x+16,160)):
    for v in range(y,mini(y+16,140)):
     chunk.tiles.append([u,v,ground_kind(Vector2(u+.5,v+.5))])
   add_child(chunk)

func _add_water_collision() -> void:
 var body := StaticBody2D.new()
 var shape := CollisionPolygon2D.new()
 shape.polygon = Space.diamond(Rect2(0,0,22,140))
 body.add_child(shape)
 body.collision_layer = 1
 body.collision_mask = 2
 add_child(body)

func _build_enclosures() -> void:
 var art: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://world/changsha/barrier-catalog.json"))
 for enclosure in plan.enclosures:
  var v: Array = enclosure.bounds
  var bounds := Rect2(v[0],v[1],v[2],v[3])
  var corners: Array[Vector2] = [bounds.position,Vector2(bounds.end.x,bounds.position.y),bounds.end,Vector2(bounds.position.x,bounds.end.y)]
  var sides = {"north":[corners[0],corners[1]],"east":[corners[1],corners[2]],"south":[corners[3],corners[2]],"west":[corners[0],corners[3]]}
  var post_points: Array[Vector2] = corners.duplicate()
  for side in sides:
   var a: Vector2 = sides[side][0]
   var b: Vector2 = sides[side][1]
   var axis: Vector2 = (b-a).normalized()
   var openings: Array = enclosure.gates.filter(func(g):return g.side==side)
   var intervals: Array = [[a,b]]
   if not openings.is_empty():
    var g: Dictionary = openings[0]
    var center := Vector2(g.center,a.y) if axis.x else Vector2(a.x,g.center)
    var half_width: float = g.clear/2+g.post
    intervals = [[a,center-axis*half_width],[center+axis*half_width,b]]
    var item = Barrier.new()
    item.gate(center,axis,g.clear,g.post,enclosure.kind,art,enclosure.id)
    depth_root.add_child(item)
    barriers.append(item)
    gate_records.append({"owner":enclosure.id,"center":center,"axis":axis,"clear":g.clear,"post":g.post,"node":item})
   for interval in intervals:
    var begin: Vector2 = interval[0]
    var stop: Vector2 = interval[1]
    wall_runs.append({"a":begin,"b":stop,"owner":enclosure.id})
    var key: String = enclosure.kind+"_"+("a" if axis.x and enclosure.kind!="city" else "b")
    var steps := maxi(1,ceili(begin.distance_to(stop)/float(art[key].module_length)))
    for j in range(steps):
     var left: Vector2 = begin.lerp(stop,float(j)/steps)
     var right: Vector2 = begin.lerp(stop,float(j+1)/steps)
     var item = Barrier.new()
     item.wall(left,right,enclosure.kind,art,enclosure.id)
     depth_root.add_child(item)
     barriers.append(item)
     if j>0:post_points.append(left)
  if enclosure.kind!="city":
   for point in post_points:
    var item = Barrier.new()
    item.post(point,enclosure.kind,art,enclosure.id)
    depth_root.add_child(item)
    barriers.append(item)

func _order_buildings() -> void:
 # Compute depth constraints once for buildings and enclosure pieces together.
 var incoming: Array[int] = []
 var following: Array = []
 for i in range(occluders.size()):
  incoming.append(0)
  following.append([])
 for i in range(occluders.size()):
  for j in range(i+1,occluders.size()):
   if Space.before(occluders[i].footprint,occluders[j].footprint):
    following[i].append(j)
    incoming[j]+=1
   elif Space.before(occluders[j].footprint,occluders[i].footprint):
    following[j].append(i)
    incoming[i]+=1
 var ready: Array[int] = []
 for i in range(incoming.size()):
  if incoming[i]==0:ready.append(i)
 while not ready.is_empty():
  ready.sort_custom(func(a,b):return occluders[a].position.y<occluders[b].position.y)
  var index: int = ready.pop_front()
  static_order.append(occluders[index])
  for next in following[index]:
   incoming[next]-=1
   if incoming[next]==0:ready.append(next)
 for item in occluders:
  if not static_order.has(item):static_order.append(item)
 for i in range(static_order.size()):depth_root.move_child(static_order[i],i)

func _process(delta: float) -> void:
 if actor == null: return
 var first: int = 0
 var last: int = static_order.size()
 var guess: int = 0
 nearest = null
 var nearest_distance: float = 3.0
 for i in range(static_order.size()):
  var b = static_order[i]
  if Space.before(b.footprint,actor.footprint): first = maxi(first,i+1)
  elif Space.before(actor.footprint,b.footprint): last = mini(last,i)
  if b.position.y < actor.position.y: guess = i+1
 for b in buildings:
  var distance: float = actor.logical.distance_to(b.approach)
  if distance < nearest_distance:
   nearest = b
   nearest_distance = distance
 var place: int = clampi(guess,first,maxi(first,last))
 depth_root.move_child(actor,mini(place,depth_root.get_child_count()-1))
 var focus: Vector2 = actor.position + Vector2(0,-40)
 for i in range(buildings.size()):
  labels[i].visible = show_labels and actor.logical.distance_to(buildings[i].approach) < 10
 for b in occluders:
  var image_rect: Rect2 = b.sprite.get_global_transform()*b.sprite.get_rect()
  var obscures: bool = depth_root.get_children().find(b) > depth_root.get_children().find(actor) and image_rect.has_point(focus)
  b.sprite.modulate.a = lerpf(b.sprite.modulate.a,0.45 if obscures else 1.0,1.0-exp(-10.0*delta))
 var city_bounds: Array = plan.city_bounds
 var district: String = "성내 길·공동 공간" if Rect2(city_bounds[0],city_bounds[1],city_bounds[2],city_bounds[3]).has_point(actor.logical) else "강변·근교"
 for zone in plan.zones:
  var b: Array = zone.bounds
  if Rect2(b[0],b[1],b[2],b[3]).has_point(actor.logical): district = zone.name
 title.text = "가라앉은 약속  ·  장사   /   %s" % district
 status.text = "WASD 이동   휠 확대/축소 %d%%   M 지도   H 안내   F 시설 확인" % roundi(camera.displayed_factor*100)
 notice.text = (info_text if info_for_id == str(nearest.entry.id) else "F · %s  — 현재 외관만 구현" % nearest.entry.name) if nearest != null else info_text
 if map_panel.visible: map_view.queue_redraw()

func _paper() -> StyleBoxFlat:
 var style := StyleBoxFlat.new()
 style.bg_color = Color("eee6d6f2")
 style.border_color = Color("77876d")
 style.set_border_width_all(1)
 style.set_content_margin_all(16)
 style.set_corner_radius_all(5)
 return style

func _build_hud() -> void:
 var layer := CanvasLayer.new()
 add_child(layer)
 var root := Control.new()
 root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 root.mouse_filter = Control.MOUSE_FILTER_IGNORE
 layer.add_child(root)
 var theme := Theme.new()
 theme.default_font = font
 theme.default_font_size = 18
 theme.set_color("font_color","Label",Color("28382e"))
 root.theme = theme
 var panel := PanelContainer.new()
 panel.position = Vector2(20,18)
 panel.add_theme_stylebox_override("panel",_paper())
 panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
 root.add_child(panel)
 var box := VBoxContainer.new()
 panel.add_child(box)
 title = Label.new()
 title.add_theme_font_size_override("font_size",22)
 box.add_child(title)
 status = Label.new()
 box.add_child(status)
 notice = Label.new()
 notice.add_theme_font_size_override("font_size",16)
 box.add_child(notice)
 var map_button := Button.new()
 map_button.text = "전체 지도 [M]"
 map_button.focus_mode = Control.FOCUS_NONE
 map_button.pressed.connect(toggle_map)
 box.add_child(map_button)
 help_panel = PanelContainer.new()
 help_panel.position = Vector2(24,160)
 help_panel.add_theme_stylebox_override("panel",_paper())
 root.add_child(help_panel)
 var help := Label.new()
 help.text = "장사 외관 탐사 · 검토용\n\n66동 + 노점8자리 / 강변·창고·시장·공방·주거·농촌\n도원 속도9.6 · 화면 가로/세로 동일 · 호흡 없음 · 휠75~175% · C 기본 배율\n1 나루  2 창고  3 관아  4 공방  5 객잔\n6 시장  7 무관  8 서남주거  9 동남주거  0 농촌\n숫자 이동은 검토 편의 기능입니다. R은 나루로 복귀합니다.\nTab 시설 이름 표시/숨김 · F2 기존 심리스 민가 시험\n\n성곽·무관 담장·농가 울타리 시험 배치\n보류: 건물 실내·거래·NPC·의뢰·수상 나루\n동쪽 논은 용수 미확정으로 마른 밭으로 구성했습니다.\n21°/23° 건물 축은 장사 장면에만 적용했습니다.\n\nH / Esc 닫기"
 help_panel.add_child(help)
 help_panel.visible = false
 map_panel = PanelContainer.new()
 map_panel.set_anchors_preset(Control.PRESET_CENTER)
 map_panel.position = Vector2(-460,-360)
 map_panel.add_theme_stylebox_override("panel",_paper())
 root.add_child(map_panel)
 map_view = MapView.new()
 map_view.custom_minimum_size = Vector2(900,690)
 map_view.city = self
 map_panel.add_child(map_view)
 map_panel.visible = false
 info_text = "나루에서 창고·시장으로 걸어보세요. H: 구현 범위와 구역 이동 안내"

func toggle_map() -> void:
 map_panel.visible = not map_panel.visible
 help_panel.visible = false
 _sync_overlay()

func _sync_overlay() -> void:
 var blocked: bool = help_panel.visible or map_panel.visible
 actor.set_physics_process(not blocked)
 if blocked:
  actor.moving = false
  actor._pose()

func review_jump(index: int) -> void:
 info_for_id = ""
 actor.set_logical(REVIEW_POINTS[index])
 info_text = "검토 이동 · %d번 구역" % (index+1)

func _unhandled_key_input(event: InputEvent) -> void:
 if not event is InputEventKey or not event.pressed or event.echo: return
 var input_viewport := get_viewport()
 match event.physical_keycode:
  KEY_M: toggle_map()
  KEY_H:
   help_panel.visible = not help_panel.visible
   map_panel.visible = false
   _sync_overlay()
  KEY_ESCAPE:
   map_panel.visible = false
   help_panel.visible = false
   _sync_overlay()
  KEY_TAB: show_labels = not show_labels
  KEY_C: camera.reset_zoom()
  KEY_R: review_jump(0)
  KEY_F:
   if nearest != null:
    info_text = "%s · 실내/기능 연결은 후속 작업입니다." % nearest.entry.name
    info_for_id = str(nearest.entry.id)
  KEY_F2: get_tree().change_scene_to_file("res://prototypes/f_style_trial/seamless.tscn")
  KEY_1: review_jump(0)
  KEY_2: review_jump(1)
  KEY_3: review_jump(2)
  KEY_4: review_jump(3)
  KEY_5: review_jump(4)
  KEY_6: review_jump(5)
  KEY_7: review_jump(6)
  KEY_8: review_jump(7)
  KEY_9: review_jump(8)
  KEY_0: review_jump(9)
  _: return
 input_viewport.set_input_as_handled()

func _exit_tree() -> void:
 for action in registered_inputs:
  Input.action_release(action)
  InputMap.erase_action(action)
