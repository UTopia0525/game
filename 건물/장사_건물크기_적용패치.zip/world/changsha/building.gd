extends Node2D
const Space = preload("res://world/changsha/space.gd")
var entry: Dictionary
var footprint: Rect2
var plot: Rect2
var door: Vector2
var approach: Vector2
var sprite: Sprite2D
var uniform_scale: float
var facing: String
func setup(info: Dictionary, art: Dictionary) -> void:
 entry = info
 facing = str(info.get("facing", "south"))
 var b: Array = info.bounds
 plot = Rect2(b[0], b[1], b[2], b[3])
 # Asset size is fixed against house_1; a larger plot supplies yard space, not a larger building.
 uniform_scale = float(art.display_scale)
 var size := Vector2(art.footprint_tiles[0],art.footprint_tiles[1])
 footprint = Rect2(Vector2(plot.get_center().x - size.x / 2, plot.end.y - size.y), size)
 if facing == "north": footprint.position.y = plot.position.y
 position = Space.project(Vector2(footprint.position.x, footprint.end.y))
 sprite = Sprite2D.new()
 sprite.centered = false
 sprite.texture = load(art.texture)
 sprite.scale = Vector2.ONE * uniform_scale
 sprite.position = -Vector2(art.anchor[0], art.anchor[1]) * uniform_scale
 sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
 add_child(sprite)
 var body := StaticBody2D.new()
 body.collision_layer = 1
 body.collision_mask = 2
 var collider := CollisionPolygon2D.new()
 var points: PackedVector2Array = Space.diamond(footprint)
 for i in range(points.size()): points[i] -= position
 collider.polygon = points
 body.add_child(collider)
 add_child(body)
 # Rear artwork hides the real entrance on the far edge, facing the same street.
 door = Vector2(footprint.position.x + footprint.size.x * float(art.door_fraction), footprint.position.y if facing == "north" else footprint.end.y)
 approach = door + Vector2(0,-0.45 if facing == "north" else 0.45)
