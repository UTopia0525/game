extends "res://prototypes/timed_combat/test_screen.gd"
## Compact presentation only. Clock, Rules, catalog and encounter are unchanged.
const PaintedBoard = preload("res://mountain/battle_board.gd")
const BOARD_DIRECTIONS = ["동쪽 →","남쪽 ↓","서쪽 ←","북쪽 ↑"]
var stage_panel: PanelContainer

func _build_ui() -> void:
	ACTION_IDS = ["basic_attack","samjae","yusu","cheongpung","basic_defense","move","wait","breathe"]
	var skin := Theme.new()
	skin.default_font = load("res://assets/fonts/NanumMyeongjo-Regular.ttf")
	skin.default_font_size = 18
	skin.set_color("font_color","Label",Color("eee4cf"))
	for kind in ["normal","hover","pressed","disabled","focus"]:
		var style := StyleBoxFlat.new()
		style.bg_color = Color("34423a") if kind in ["hover","pressed"] else Color("202d29")
		style.border_color = Color("a99870") if kind == "focus" else Color("647264")
		style.set_border_width_all(1)
		style.set_corner_radius_all(5)
		style.content_margin_left = 12
		style.content_margin_right = 12
		style.content_margin_top = 6
		style.content_margin_bottom = 6
		skin.set_stylebox(kind,"Button",style)
		skin.set_stylebox(kind,"OptionButton",style)
	theme = skin
	var backdrop := ColorRect.new()
	backdrop.color = Color("111c19")
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(backdrop)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_"+side,12)
	add_child(margin)
	var root_box := VBoxContainer.new()
	root_box.add_theme_constant_override("separation",8)
	margin.add_child(root_box)
	var toolbar := HBoxContainer.new()
	toolbar.add_theme_constant_override("separation",10)
	root_box.add_child(toolbar)
	var title := _label(toolbar,"산골의 조우")
	title.add_theme_font_override("font",load("res://assets/fonts/NanumBrushScript-Regular.ttf"))
	title.add_theme_font_size_override("font_size",32)
	for index in range(2):
		var panel := _panel(7)
		panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		toolbar.add_child(panel)
		var label := _label(panel,"")
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.add_theme_font_size_override("font_size",17)
		label.add_theme_color_override("font_color",Board.PLAYER_COLOR if index==0 else Board.ENEMY_COLOR)
		status_labels.append(label)
	time_label = _label(toolbar,"")
	time_label.add_theme_color_override("font_color",Color("c5b58f"))
	var grid_toggle := CheckButton.new()
	grid_toggle.text = "격자"
	grid_toggle.button_pressed = true
	grid_toggle.toggled.connect(func(value): board.set("show_grid",value);board.queue_redraw())
	toolbar.add_child(grid_toggle)
	restart_button = _button(toolbar,"다시 시작",func(): restart_scenario(0))
	end_button = _button(toolbar,"종료",end_trial)
	stage_panel = _panel(0)
	stage_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stage_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root_box.add_child(stage_panel)
	board = PaintedBoard.new()
	stage_panel.add_child(board)
	var announce_panel := _panel(8)
	board.add_child(announce_panel)
	announce_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	announce_panel.offset_left = -390
	announce_panel.offset_right = -12
	announce_panel.offset_top = 12
	announce_panel.offset_bottom = 77
	announcement_label = _label(announce_panel,"")
	announcement_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	announcement_label.add_theme_font_size_override("font_size",17)
	announcement_label.add_theme_color_override("font_color",Color("f4b076"))
	var controls_panel := _panel(8)
	root_box.add_child(controls_panel)
	var controls := VBoxContainer.new()
	controls.add_theme_constant_override("separation",5)
	controls_panel.add_child(controls)
	var choices := HBoxContainer.new()
	choices.add_theme_constant_override("separation",10)
	controls.add_child(choices)
	_label(choices,"행동")
	action_picker = OptionButton.new()
	for id in ACTION_IDS: action_picker.add_item(Rules.ACTIONS[id].name)
	action_picker.item_selected.connect(func(_item): refresh_view())
	choices.add_child(action_picker)
	direction_picker = OptionButton.new()
	for value in BOARD_DIRECTIONS: direction_picker.add_item(value)
	direction_picker.item_selected.connect(func(_item): refresh_view())
	choices.add_child(direction_picker)
	commit_button = _button(choices,"행동 확정",commit_selected)
	next_button = _button(choices,"다음 사건",step_event)
	preview_label = _label(choices,"")
	preview_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	preview_label.add_theme_font_size_override("font_size",17)
	notice_label = _label(controls,"")
	notice_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	notice_label.add_theme_font_size_override("font_size",17)
	notice_label.add_theme_color_override("font_color",Color("e4c986"))
	# Keep event history internally; no visible combat log or side column.
	var hidden := Control.new()
	hidden.hide()
	add_child(hidden)
	log_view = RichTextLabel.new()
	hidden.add_child(log_view)
	scenario_picker = OptionButton.new()
	scenario_picker.add_item("산골 1대1")
	hidden.add_child(scenario_picker)
	weapon_picker = OptionButton.new()
	hidden.add_child(weapon_picker)
	loadout_picker = OptionButton.new()
	hidden.add_child(loadout_picker)
	scenario_label = _label(hidden,"")

func refresh_view() -> void:
	super.refresh_view()
	var state: Dictionary = clock.snapshot()
	if state.units.size()!=2: return
	time_label.text = "T %.3f" % state.time_t
	for index in range(2):
		var unit: Dictionary = state.units[index]
		var phase: String = PHASE_NAMES[unit.phase] if state.result=="ongoing" else "교전 종료"
		var action_name: String = "" if unit.action.is_empty() else " · "+unit.action.name
		status_labels[index].text = "%s · HP %d/%d · 내기 %.1f\n%s%s" % [_actor_name(index),unit.hp,unit.max_hp,unit.qi,phase,action_name]
	var enemy: Dictionary = clock.enemy_announcement()
	announcement_label.tooltip_text = announcement_label.text
	if enemy.is_empty():
		announcement_label.text = "산적 · 예정 행동 없음"
	else:
		announcement_label.text = "산적 예고  %s · %s\n발동 %.3fT · %s" % [enemy.name,_direction(enemy.facing),enemy.impact_t,"출수 중" if enemy.phase=="windup" else "회수 중"]
	var id: String = ACTION_IDS[action_picker.selected]
	var data: Dictionary = Rules.ACTIONS[id]
	var unit: Dictionary = state.units[0]
	preview_label.tooltip_text = preview_label.text
	preview_label.text = "내기 %d  ·  출수 %.3fT / 회수 %.3fT" % [Rules.qi_cost(id,unit.weapon),float(Rules.duration_ticks(data.cast,unit.stats.agility))/Rules.TIME_SCALE,float(Rules.duration_ticks(data.recovery,unit.stats.agility))/Rules.TIME_SCALE]
	var preview: Dictionary = clock.preview(0,id,Rules.DIRECTIONS[direction_picker.selected])
	if state.result!="ongoing" or _ended:
		notice_label.text = "%s · 다시 시작할 수 있습니다." % RESULT_NAMES.get(state.result,"교전 종료")
	elif not _enemy_blocked.is_empty():
		notice_label.text = "산적 행동 불가 · "+_enemy_blocked
	elif 0 in clock.awaiting_choices():
		notice_label.text = "산적 예고 확인 → 행동·방향 선택 → 확정" if preview.ok else _reason(preview.reason)
	else:
		notice_label.text = "행동 확정됨 · 다음 사건으로 진행"

func restart_scenario(_index: int) -> void:
	if not _enter_command(): return
	clock.cancel_battle()
	clock = Clock.new()
	_ended = false
	_enemy_blocked = ""
	_enemy_cursor = 0
	_event_cursor = 0
	_history = []
	_last_facings = [Vector2i.RIGHT,Vector2i.LEFT]
	_enemy_steps = ["move","breathe","danseok","basic_defense","breathe","chupung"]
	var setup: Dictionary = clock.setup([_actor(Vector2i(2,2),"refined_sword"),_actor(Vector2i(4,2),"thickback_saber")],Vector2i(7,5))
	if not setup.ok: _enemy_blocked = setup.reason
	action_picker.select(ACTION_IDS.find("samjae"))
	direction_picker.select(0)
	_ensure_enemy_plan()
	_collect_events()
	refresh_view()

func _ensure_enemy_plan() -> void:
	if _ended or 1 not in clock.awaiting_choices() or not _enemy_blocked.is_empty(): return
	var state: Dictionary = clock.snapshot()
	var delta: Vector2i = state.units[0].position-state.units[1].position
	var facing := Vector2i.LEFT
	if delta != Vector2i.ZERO:
		facing = Vector2i(signi(delta.x),0) if absi(delta.x)>=absi(delta.y) else Vector2i(0,signi(delta.y))
	var id: String = _enemy_steps[_enemy_cursor % _enemy_steps.size()]
	var result: Dictionary = clock.commit_action(1,id,facing)
	if result.ok:
		_enemy_cursor += 1
		_last_facings[1] = facing
	else:
		_enemy_blocked = "%s: %s" % [Rules.ACTIONS[id].name,_reason(result.reason)]
		_history.append(" 산적 고정 행동 불가 · "+_enemy_blocked+" · 대체하지 않음")

func _actor_name(index: int) -> String:
	return "도원" if index==0 else "산적"

func _direction(value: Vector2i) -> String:
	return BOARD_DIRECTIONS[Rules.DIRECTIONS.find(value)]

func _panel(padding: int = 12) -> PanelContainer:
	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color("192622")
	style.border_color = Color("536257")
	style.set_border_width_all(1)
	style.set_corner_radius_all(7)
	style.content_margin_left = padding
	style.content_margin_right = padding
	style.content_margin_top = padding
	style.content_margin_bottom = padding
	panel.add_theme_stylebox_override("panel",style)
	return panel
