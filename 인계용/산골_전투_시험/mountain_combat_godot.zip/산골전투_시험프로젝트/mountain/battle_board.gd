extends "res://prototypes/timed_combat/test_board.gd"
## Art adapter only. Every location/range/effect is supplied by the existing clock.
const BACKGROUND = preload("res://mountain/assets/mountain.png")
const POSES = preload("res://mountain/assets/battle_poses.png")
const JUMP_POSES = preload("res://mountain/assets/jump_poses.png")
signal visual_motion_finished
@export var jump_anticipation := 0.06
@export var jump_flight := 0.30
@export var jump_landing := 0.10
@export var jump_height_in_cells := 0.35
var _jump_tracks: Array = [{},{}]
var _had_motion := false
var show_grid := true
var _seen_events := 0
var _seen_time := -1
var _pose_until := [0, 0]
var _pose_index := [0, 0]
var _damage_text := ["", ""]
@export var breathing_enabled := true
@export_range(0.0,10.0,0.25) var breathing_source_amplitude := 6.0
const BREATH_PERIODS = [1.6,1.85]
const BREATH_PHASES = [0.0,0.37]
const BREATH_ROWS = [0.0,420.0,435.0,450.0,465.0,480.0,485.0,512.0]
var _breathing_time := 0.0
var _breathing_blend := [0.0,0.0]

func _ready() -> void:
	custom_minimum_size = Vector2(600, 400)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func present(state: Dictionary, selected: Array, announced: Array, movement: Array, last_facings: Array) -> void:
	if int(state.time_ticks) < _seen_time or state.events.size() < _seen_events:
		_seen_events = 0
		_pose_until = [0, 0]
		_damage_text = ["", ""]
		_jump_tracks = [{},{}]
	var now := Time.get_ticks_msec()
	for i in range(_seen_events, state.events.size()):
		var event: Dictionary = state.events[i]
		if event.kind=="moved" and not view.is_empty():
			var action: Dictionary = state.units[event.actor].action
			if action.get("id","")=="move" and state.units[event.actor].hp>0 and event.position==state.units[event.actor].position:
				_start_jump(event.actor,view.units[event.actor].position,event.position)
		elif event.kind in ["forced_move","dead"]:
			_jump_tracks[event.actor] = {}
		elif event.kind in ["cancelled","finished"]:
			_jump_tracks = [{},{}]
		if event.kind == "effect" and event.get("attack", false):
			if now >= _pose_until[event.actor]:
				_damage_text[event.actor] = ""
			_pose_index[event.actor] = 1
			_pose_until[event.actor] = now + 650
			if event.hit:
				# Visual cancellation only; damage and logical destination are already resolved.
				_jump_tracks[1-event.actor] = {}
				_pose_index[1-event.actor] = 3
				_pose_until[1-event.actor] = now + 650
				_damage_text[1-event.actor] = "−%d" % event.damage
	_seen_events = state.events.size()
	_seen_time = int(state.time_ticks)
	super.present(state, selected, announced, movement, last_facings)

func _process(delta: float) -> void:
	# Cosmetic time only; never advances, selects or edits the combat clock.
	_breathing_time += delta
	for index in range(2):
		if not _jump_tracks[index].is_empty() and _breathing_time-float(_jump_tracks[index].started)>=jump_anticipation+jump_flight+jump_landing:
			_jump_tracks[index] = {}
	if _had_motion and not is_motion_busy():
		_had_motion = false
		visual_motion_finished.emit()
	for index in range(2):
		var target := 1.0 if _should_breathe(index) else 0.0
		_breathing_blend[index] = move_toward(float(_breathing_blend[index]),target,delta/0.18)
	queue_redraw()

func _pose_for(index: int) -> int:
	var unit: Dictionary = view.units[index]
	if unit.hp==0: return 3
	if Time.get_ticks_msec()<_pose_until[index]: return int(_pose_index[index])
	if not unit.action.is_empty() and unit.action.id=="basic_defense" and unit.phase=="recovery": return 2
	return 0

func _should_breathe(index: int) -> bool:
	return breathing_enabled and not is_jumping(index) and not view.is_empty() and view.units.size()>index and view.result=="ongoing" and view.units[index].hp>0 and _pose_for(index)==0

func is_jumping(index: int) -> bool:
	return not _jump_tracks[index].is_empty()

func is_motion_busy() -> bool:
	return is_jumping(0) or is_jumping(1)

func _start_jump(index: int, start: Vector2i, finish: Vector2i) -> void:
	if start==finish: return
	var head_room := minf(cell_center(start).y,cell_center(finish).y)-_cell_size().y*2.0*484.0/512.0-12.0
	var height := minf(_cell_size().y*jump_height_in_cells,maxf(0.0,head_room))
	_jump_tracks[index] = {"from":start,"to":finish,"started":_breathing_time,"height":height}
	_had_motion = true

func jump_sample(index: int, elapsed: float) -> Dictionary:
	var track: Dictionary = _jump_tracks[index]
	var takeoff: Vector2 = cell_center(track["from"])
	var landing: Vector2 = cell_center(track.to)
	if elapsed<jump_anticipation:
		return {"ground":takeoff,"lift":0.0,"pose":0,"air":0.0}
	if elapsed>=jump_anticipation+jump_flight:
		var settle := elapsed-jump_anticipation-jump_flight
		return {"ground":landing,"lift":0.0,"pose":3 if settle<jump_landing*0.55 else 1,"air":0.0}
	var u := clampf((elapsed-jump_anticipation)/jump_flight,0.0,1.0)
	var arc := 4.0*u*(1.0-u)
	# A low, extended-leg hop: no deep knee tuck at the apex.
	return {"ground":takeoff.lerp(landing,smoothstep(0.0,1.0,u)),"lift":float(track.height)*arc,"pose":1,"air":arc}

func _current_jump(index: int) -> Dictionary:
	return jump_sample(index,_breathing_time-float(_jump_tracks[index].started))

func _ground_center(index: int) -> Vector2:
	return _current_jump(index).ground if is_jumping(index) else marker_center(index)

func breathing_offset_at(index: int, source_y: float, seconds: float) -> Vector2:
	if not breathing_enabled: return Vector2.ZERO
	# Upper body, head, hands and weapons translate rigidly; only the lower calf
	# transition compensates. Soles below485 and the logical foot anchor never move.
	var weight := 1.0-smoothstep(420.0,485.0,source_y)
	var wave := (1.0-cos(TAU*(seconds/float(BREATH_PERIODS[index])+float(BREATH_PHASES[index]))))*0.5
	return Vector2(0.0,-breathing_source_amplitude*wave*weight)

func _draw_breathing_actor(index: int, origin: Vector2, scale_factor: float, tint: Color) -> void:
	for row in range(BREATH_ROWS.size()-1):
		var y0: float = BREATH_ROWS[row]
		var y1: float = BREATH_ROWS[row+1]
		var offset0 := breathing_offset_at(index,y0,_breathing_time)*float(_breathing_blend[index])
		var offset1 := breathing_offset_at(index,y1,_breathing_time)*float(_breathing_blend[index])
		var polygon := PackedVector2Array([origin+(Vector2(0,y0)+offset0)*scale_factor,origin+(Vector2(384,y0)+offset0)*scale_factor,origin+(Vector2(384,y1)+offset1)*scale_factor,origin+(Vector2(0,y1)+offset1)*scale_factor])
		var uv := PackedVector2Array([Vector2(0,(index*512+y0)/1024.0),Vector2(384.0/1536.0,(index*512+y0)/1024.0),Vector2(384.0/1536.0,(index*512+y1)/1024.0),Vector2(0,(index*512+y1)/1024.0)])
		draw_polygon(polygon,PackedColorArray([tint,tint,tint,tint]),uv,POSES)

func _cell_size() -> Vector2:
	var side := minf(128.0, minf((size.x-96.0)/9.45, (size.y-220.0)/5.0))
	return Vector2(side*1.35,side)

func _half_tile() -> float:
	# Keeps character art uniformly scaled; no change to logical distances.
	return _cell_size().y*2.0/3.6

func _origin() -> Vector2:
	var extent := _cell_size()*Vector2(7,5)
	return Vector2((size.x-extent.x)*0.5,size.y-extent.y-28.0)

func cell_center(point: Vector2i) -> Vector2:
	return _origin() + (Vector2(point)+Vector2.ONE*0.5)*_cell_size()

func _polygon(point: Vector2i) -> PackedVector2Array:
	var c := cell_center(point)
	var h := _cell_size()*0.5
	return PackedVector2Array([c+Vector2(-h.x,-h.y),c+Vector2(h.x,-h.y),c+Vector2(h.x,h.y),c+Vector2(-h.x,h.y)])

func marker_center(index: int) -> Vector2:
	# Preserve exact logical position even when both actors occupy the same tile.
	return cell_center(view.units[index].position)

func _draw() -> void:
	var image_size := Vector2(BACKGROUND.get_size())
	var ratio := maxf(size.x/image_size.x, size.y/image_size.y)
	var source_size := size/ratio
	draw_texture_rect_region(BACKGROUND, Rect2(Vector2.ZERO,size), Rect2((image_size-source_size)*0.5,source_size))
	draw_rect(Rect2(Vector2.ZERO,size),Color(0.05,0.08,0.06,0.10))
	if view.is_empty(): return
	var font := get_theme_default_font()
	for y in range(view.board_size.y):
		for x in range(view.board_size.x):
			var point := Vector2i(x,y)
			var polygon := _polygon(point)
			if show_grid:
				draw_colored_polygon(polygon, Color(0.20,0.22,0.13,0.035))
				draw_polyline(PackedVector2Array([polygon[0],polygon[1],polygon[2],polygon[3],polygon[0]]),Color(0.94,0.90,0.70,0.30),1,true)
			if point in player_cells:
				draw_colored_polygon(polygon,Color(0.12,0.78,0.71,0.30))
			if point in enemy_cells:
				draw_colored_polygon(polygon,Color(0.96,0.30,0.12,0.15))
				draw_polyline(PackedVector2Array([polygon[0],polygon[1],polygon[2],polygon[3],polygon[0]]),ENEMY_COLOR,2.5,true)
			if point in move_cell:
				draw_circle(cell_center(point),5,PLAYER_COLOR)
	var order: Array = [0,1]
	if _ground_center(0).y > _ground_center(1).y: order.reverse()
	for index in order:
		var unit: Dictionary = view.units[index]
		var ground := _ground_center(index)
		var motion: Dictionary = _current_jump(index) if is_jumping(index) else {"lift":0.0,"air":0.0}
		var center := ground-Vector2(0,float(motion.lift))
		var color: Color = PLAYER_COLOR if index == 0 else ENEMY_COLOR
		draw_set_transform(ground,0,Vector2(1,0.42))
		draw_circle(Vector2.ZERO,_half_tile()*0.36*(1.0-float(motion.air)*0.30),Color(0.10,0.08,0.05,0.32-float(motion.air)*0.14))
		draw_arc(Vector2.ZERO,_half_tile()*0.41,0,TAU,40,color,2,true)
		draw_set_transform(Vector2.ZERO)
		var pose := _pose_for(index)
		var scale_factor := _half_tile()*3.6/512.0
		var actor_size := Vector2(384,512)*scale_factor
		var actor_rect := Rect2(center-Vector2(192,500)*scale_factor,actor_size)
		var tint := Color(0.50,0.50,0.50,0.65) if unit.hp == 0 else Color.WHITE
		if is_jumping(index):
			draw_texture_rect_region(JUMP_POSES,actor_rect,Rect2(int(motion.pose)*384,index*512,384,512),tint)
		elif pose==0 and _should_breathe(index) and float(_breathing_blend[index])>0.0:
			_draw_breathing_actor(index,actor_rect.position,scale_factor,tint)
		else:
			draw_texture_rect_region(POSES,actor_rect,Rect2(pose*384,index*512,384,512),tint)
		var facing: Vector2i = facings[index]
		if not unit.action.is_empty(): facing = unit.action.facing
		var arrow := cell_center(unit.position+facing)-cell_center(unit.position)
		arrow = arrow.normalized()*_half_tile()*0.65
		draw_line(ground,ground+arrow,color,3,true)
		var side := arrow.normalized().orthogonal()*5
		draw_line(ground+arrow,ground+arrow-arrow.normalized()*8+side,color,2,true)
		draw_line(ground+arrow,ground+arrow-arrow.normalized()*8-side,color,2,true)
		var label_position := ground+Vector2(-24,22+index*3)
		draw_style_box(_tag_style(),Rect2(label_position+Vector2(-5,-15),Vector2(90,23)))
		draw_string(font,label_position,"도원" if index==0 else "산적",HORIZONTAL_ALIGNMENT_LEFT,-1,16,color)
		if Time.get_ticks_msec() < _pose_until[index] and not _damage_text[index].is_empty():
			draw_string(font,center+Vector2(-24,-actor_size.y-5),_damage_text[index],HORIZONTAL_ALIGNMENT_LEFT,-1,25,Color("ffe0aa"))
	if view.units[0].position == view.units[1].position:
		draw_string(font,Vector2(18,size.y-18),"같은 칸 중첩 · 위치를 벌려 표시하지 않음",HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color("fff2cb"))

func _tag_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.06,0.10,0.09,0.80)
	style.set_corner_radius_all(4)
	return style
