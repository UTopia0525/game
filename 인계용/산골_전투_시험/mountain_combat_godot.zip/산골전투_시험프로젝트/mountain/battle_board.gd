extends "res://prototypes/timed_combat/test_board.gd"
## Art adapter only. Every location/range/effect is supplied by the existing clock.
const BACKGROUND = preload("res://mountain/assets/mountain.png")
const POSES = preload("res://mountain/assets/battle_poses.png")
var show_grid := true
var _seen_events := 0
var _seen_time := -1
var _pose_until := [0, 0]
var _pose_index := [0, 0]
var _damage_text := ["", ""]

func _ready() -> void:
	custom_minimum_size = Vector2(600, 400)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func present(state: Dictionary, selected: Array, announced: Array, movement: Array, last_facings: Array) -> void:
	if int(state.time_ticks) < _seen_time or state.events.size() < _seen_events:
		_seen_events = 0
		_pose_until = [0, 0]
		_damage_text = ["", ""]
	var now := Time.get_ticks_msec()
	for i in range(_seen_events, state.events.size()):
		var event: Dictionary = state.events[i]
		if event.kind == "effect" and event.get("attack", false):
			if now >= _pose_until[event.actor]:
				_damage_text[event.actor] = ""
			_pose_index[event.actor] = 1
			_pose_until[event.actor] = now + 650
			if event.hit:
				_pose_index[1-event.actor] = 3
				_pose_until[1-event.actor] = now + 650
				_damage_text[1-event.actor] = "−%d" % event.damage
	_seen_events = state.events.size()
	_seen_time = int(state.time_ticks)
	super.present(state, selected, announced, movement, last_facings)

func _process(_delta: float) -> void:
	# Cosmetic time only; never advances, selects or edits the combat clock.
	queue_redraw()

func _cell_size() -> Vector2:
	var side := minf(128.0, minf((size.x-96.0)/9.45, (size.y-220.0)/5.0))
	return Vector2(side*1.35,side)

func _half_tile() -> float:
	# Keeps character art uniformly scaled; no change to logical distances.
	return _cell_size().y*2.0/3.6

func _origin() -> Vector2:
	var extent := _cell_size()*Vector2(7,5)
	return Vector2((size.x-extent.x)*0.5,size.y-extent.y-28.0)

func cell_center(point: Vector2i) -> Vector2:
	return _origin() + (Vector2(point)+Vector2.ONE*0.5)*_cell_size()

func _polygon(point: Vector2i) -> PackedVector2Array:
	var c := cell_center(point)
	var h := _cell_size()*0.5
	return PackedVector2Array([c+Vector2(-h.x,-h.y),c+Vector2(h.x,-h.y),c+Vector2(h.x,h.y),c+Vector2(-h.x,h.y)])

func marker_center(index: int) -> Vector2:
	# Preserve exact logical position even when both actors occupy the same tile.
	return cell_center(view.units[index].position)

func _draw() -> void:
	var image_size := Vector2(BACKGROUND.get_size())
	var ratio := maxf(size.x/image_size.x, size.y/image_size.y)
	var source_size := size/ratio
	draw_texture_rect_region(BACKGROUND, Rect2(Vector2.ZERO,size), Rect2((image_size-source_size)*0.5,source_size))
	draw_rect(Rect2(Vector2.ZERO,size),Color(0.05,0.08,0.06,0.10))
	if view.is_empty(): return
	var font := get_theme_default_font()
	for y in range(view.board_size.y):
		for x in range(view.board_size.x):
			var point := Vector2i(x,y)
			var polygon := _polygon(point)
			if show_grid:
				draw_colored_polygon(polygon, Color(0.20,0.22,0.13,0.035))
				draw_polyline(PackedVector2Array([polygon[0],polygon[1],polygon[2],polygon[3],polygon[0]]),Color(0.94,0.90,0.70,0.30),1,true)
			if point in player_cells:
				draw_colored_polygon(polygon,Color(0.12,0.78,0.71,0.30))
			if point in enemy_cells:
				draw_colored_polygon(polygon,Color(0.96,0.30,0.12,0.15))
				draw_polyline(PackedVector2Array([polygon[0],polygon[1],polygon[2],polygon[3],polygon[0]]),ENEMY_COLOR,2.5,true)
			if point in move_cell:
				draw_circle(cell_center(point),5,PLAYER_COLOR)
	var order: Array = [0,1]
	if marker_center(0).y > marker_center(1).y: order.reverse()
	for index in order:
		var unit: Dictionary = view.units[index]
		var center := marker_center(index)
		var color: Color = PLAYER_COLOR if index == 0 else ENEMY_COLOR
		draw_set_transform(center,0,Vector2(1,0.42))
		draw_circle(Vector2.ZERO,_half_tile()*0.36,Color(0.10,0.08,0.05,0.32))
		draw_arc(Vector2.ZERO,_half_tile()*0.41,0,TAU,40,color,2,true)
		draw_set_transform(Vector2.ZERO)
		var pose := 0
		if unit.hp == 0:
			pose = 3
		elif Time.get_ticks_msec() < _pose_until[index]:
			pose = _pose_index[index]
		elif not unit.action.is_empty() and unit.action.id == "basic_defense" and unit.phase == "recovery":
			pose = 2
		var scale_factor := _half_tile()*3.6/512.0
		var actor_size := Vector2(384,512)*scale_factor
		var actor_rect := Rect2(center-Vector2(192,500)*scale_factor,actor_size)
		var tint := Color(0.50,0.50,0.50,0.65) if unit.hp == 0 else Color.WHITE
		draw_texture_rect_region(POSES,actor_rect,Rect2(pose*384,index*512,384,512),tint)
		var facing: Vector2i = facings[index]
		if not unit.action.is_empty(): facing = unit.action.facing
		var arrow := cell_center(unit.position+facing)-center
		arrow = arrow.normalized()*_half_tile()*0.65
		draw_line(center,center+arrow,color,3,true)
		var side := arrow.normalized().orthogonal()*5
		draw_line(center+arrow,center+arrow-arrow.normalized()*8+side,color,2,true)
		draw_line(center+arrow,center+arrow-arrow.normalized()*8-side,color,2,true)
		var label_position := center+Vector2(-24,22+index*3)
		draw_style_box(_tag_style(),Rect2(label_position+Vector2(-5,-15),Vector2(90,23)))
		draw_string(font,label_position,"도원" if index==0 else "산적",HORIZONTAL_ALIGNMENT_LEFT,-1,16,color)
		if Time.get_ticks_msec() < _pose_until[index] and not _damage_text[index].is_empty():
			draw_string(font,center+Vector2(-24,-actor_size.y-5),_damage_text[index],HORIZONTAL_ALIGNMENT_LEFT,-1,25,Color("ffe0aa"))
	if view.units[0].position == view.units[1].position:
		draw_string(font,Vector2(18,size.y-18),"같은 칸 중첩 · 위치를 벌려 표시하지 않음",HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color("fff2cb"))

func _tag_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.06,0.10,0.09,0.80)
	style.set_corner_radius_all(4)
	return style
