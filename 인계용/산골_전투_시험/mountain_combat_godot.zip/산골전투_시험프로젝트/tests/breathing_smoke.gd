extends SceneTree
var checks := 0
var failures: Array = []

func _initialize() -> void:
	_run.call_deferred()

func _check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures.append(message)
		push_error(message)

func _run() -> void:
	var screen = load("res://mountain/main.tscn").instantiate()
	root.add_child(screen)
	await process_frame
	await process_frame
	var board = screen.board
	var before: Dictionary = screen.clock.snapshot()
	var plan: Dictionary = screen.clock.enemy_announcement()
	var cosmetic_before: float = board._breathing_time
	await create_timer(2.0).timeout
	_check(board._breathing_time>cosmetic_before,"실제 프레임에서 호흡 시간 진행")
	_check(screen.clock.snapshot()==before,"호흡 중 논리 시간·체력·내기·상태·사건 불변")
	_check(screen.clock.enemy_announcement()==plan,"호흡 중 적 예고 불변")
	for actor in range(2):
		for sample in [0.0,0.4,0.8,1.2]:
			var head: Vector2 = board.breathing_offset_at(actor,80,sample)
			_check(is_zero_approx(head.x),"좌우 흔들림 없음")
			_check(board.breathing_offset_at(actor,200,sample)==head and board.breathing_offset_at(actor,380,sample)==head,"머리·몸통·무기 영역의 상대 크기와 방향 유지")
			_check(board.breathing_offset_at(actor,485,sample)==Vector2.ZERO and board.breathing_offset_at(actor,500,sample)==Vector2.ZERO,"발바닥·등록점 고정")
			_check(head.y<=0 and head.y>=-6.0,"과도한 상체 이동 없음")
	var key := InputEventKey.new()
	key.physical_keycode = KEY_B
	key.pressed = true
	screen._unhandled_key_input(key)
	_check(not board.breathing_enabled and not board._should_breathe(0),"B로 호흡 끄기")
	_check(board.breathing_offset_at(0,80,0.8)==Vector2.ZERO,"끄면 원본 자세")
	screen._unhandled_key_input(key)
	_check(board.breathing_enabled,"B로 호흡 켜기")
	board._pose_index[0] = 1
	board._pose_until[0] = Time.get_ticks_msec()+10000
	_check(not board._should_breathe(0),"공격 자세에 호흡 변형 미적용")
	board._pose_until[0] = 0
	_check(board._should_breathe(0),"대기 자세 호흡 복귀")
	var output := OS.get_environment("GARA_BREATH_CAPTURE_DIR")
	if not output.is_empty() and DisplayServer.get_name()!="headless":
		DirAccess.make_dir_recursive_absolute(output)
		board.set_process(false)
		board._breathing_blend = [1.0,1.0]
		# A character-only effect preview at fixed combat T; not a gameplay recording.
		for frame in range(32):
			board._breathing_time = frame*1.6/32.0
			board.queue_redraw()
			await RenderingServer.frame_post_draw
			var image: Image = root.get_texture().get_image()
			var ratio: Vector2 = Vector2(image.get_size())/screen.size
			var center: Vector2 = board.global_position+board.marker_center(0)
			var height: float = board._half_tile()*3.6
			var region := Rect2i((center-Vector2(140,height+12))*ratio,Vector2(280,height+64)*ratio)
			var error := image.get_region(region).save_png(output.path_join("idle_%02d.png" % frame))
			_check(error==OK,"효과 검토 프레임 저장")
	_check(screen.clock.snapshot()==before,"검토 캡처 뒤에도 전투 상태 불변")
	screen.end_trial()
	_check(not board._should_breathe(0) and not board._should_breathe(1),"교전 종료 뒤 호흡 중단")
	print("BREATHING_SMOKE: %d checks, %d failures" % [checks,failures.size()])
	if not output.is_empty():
		var file := FileAccess.open(output.path_join("breathing-result.json"),FileAccess.WRITE)
		file.store_string(JSON.stringify({"checks":checks,"failures":failures,"display":DisplayServer.get_name(),"combat_T_before":before.time_t,"combat_T_after":screen.clock.snapshot().time_t,"source_amplitude":6,"periods":[1.6,1.85]},"  "))
	screen.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
