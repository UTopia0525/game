extends SceneTree
## One deterministic scene integration check; never touches production saves.
var checks := 0
var failures: Array = []
var screen

func _initialize() -> void:
	_run.call_deferred()

func _check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures.append(message)
		push_error(message)

func _click(button: Button) -> void:
	while screen.board.is_motion_busy():
		await process_frame
	button.pressed.emit()
	await process_frame
	await process_frame
	while screen.board.is_motion_busy():
		await process_frame

func _choose(id: String) -> void:
	screen.action_picker.select(screen.ACTION_IDS.find(id))
	screen.refresh_view()

func _capture(name: String) -> void:
	if DisplayServer.get_name() == "headless": return
	await RenderingServer.frame_post_draw
	var output := OS.get_environment("GARA_CAPTURE_DIR")
	if output.is_empty(): return
	DirAccess.make_dir_recursive_absolute(output)
	var error := root.get_texture().get_image().save_png(output.path_join(name+".png"))
	_check(error==OK,"실제 뷰포트 PNG 저장")

func _run() -> void:
	screen = load("res://mountain/main.tscn").instantiate()
	root.add_child(screen)
	await process_frame
	await process_frame
	var initial: Dictionary = screen.clock.snapshot()
	_check(initial.units.size()==2,"두 전투원")
	_check(initial.units[0].hp==530 and initial.units[1].hp==530,"기존 총합150 체력530")
	_check(initial.units[0].qi==34 and initial.units[1].qi==34,"시작 내기34 유지")
	var enemy: Dictionary = screen.clock.enemy_announcement()
	_check(enemy.id=="move" and enemy.facing==Vector2i.LEFT,"산적 먼저 고정 이동 확정")
	_check(not screen.commit_button.disabled,"유효한 삼재검법 확정 버튼 활성")
	var center: Vector2 = screen.board.cell_center(Vector2i(0,0))
	var east: Vector2 = screen.board.cell_center(Vector2i(1,0))-center
	var south: Vector2 = screen.board.cell_center(Vector2i(0,1))-center
	_check(east.x>0 and is_zero_approx(east.y),"격자 동서 축 수평")
	_check(south.y>0 and is_zero_approx(south.x),"격자 남북 축 수직")
	_check(is_equal_approx(screen.board.marker_center(0).y,screen.board.marker_center(1).y),"같은 행 전투원 높이 정렬")
	_check(not screen.log_view.is_visible_in_tree(),"전투 기록 비표시")
	_check(screen.stage_panel.size.x>screen.get_viewport_rect().size.x*0.95,"전투 영역 전체 폭 사용")
	_check(screen.stage_panel.size.y>screen.get_viewport_rect().size.y*0.74,"전투 영역 높이74% 초과")
	await _capture("01_산골_시작")
	for id in screen.ACTION_IDS:
		_choose(id)
		_check(screen.clock.snapshot().time_ticks==0,"선택 중 시간 불변: "+id)
		_check(screen.clock.enemy_announcement()==enemy,"선택 중 산적 행동 재추첨 없음")
	_choose("cheongpung")
	_check(screen.commit_button.disabled,"내기 부족 행동 버튼 비활성")
	await _click(screen.commit_button)
	_check(screen.clock.snapshot().units[0].qi==34,"내기 부족 시 무소비")
	_choose("samjae")
	_check(screen.next_button.disabled,"플레이어 선택 필요 시 진행 금지")
	screen.commit_button.pressed.emit()
	screen.commit_button.pressed.emit()
	await process_frame
	await process_frame
	_check(screen.clock.snapshot().units[0].qi==4,"중복 확정 방지와 비용30 한 번 차감")
	_check(screen.clock.snapshot().time_ticks==0,"확정만으로 시간 불변")
	await _click(screen.next_button)
	_check(screen.clock.snapshot().units[1].position==Vector2i(3,2),"첫 사건에서 산적 이동")
	_check(screen.clock.snapshot().units[1].hp==530,"출수 전 피해 없음")
	for unused in range(8):
		if screen.clock.snapshot().units[1].hp<530: break
		await _click(screen.next_button)
	_check(screen.clock.snapshot().units[1].hp==455,"삼재검법 원위력72 ×정련검1.05=75 피해")
	_check(screen.board.view.units[1].hp==455,"보드가 실제 엔진 상태 표시")
	await _capture("02_삼재검법_명중")
	var old_clock = screen.clock
	await _click(screen.end_button)
	_check(old_clock.snapshot().result=="cancelled","종료 처리")
	_check(not old_clock.advance_next().ok,"종료 뒤 예약 효과 진행 거부")
	await _click(screen.restart_button)
	_check(screen.clock!=old_clock and screen.clock.snapshot().time_ticks==0,"새 교전으로 재시작")
	_check(screen.clock.snapshot().units[0].hp==530,"재시작 체력 복원")
	_choose("breathe")
	await _click(screen.commit_button)
	for unused in range(12):
		if 0 in screen.clock.awaiting_choices(): break
		await _click(screen.next_button)
	_check(screen.clock.snapshot().units[0].qi>=120,"기존 회복식으로 청풍 비용 확보")
	_choose("cheongpung")
	_check(not screen.commit_button.disabled,"숨 고르기 뒤 실제 선택 가능")
	await _click(screen.restart_button)
	# A single wait-only encounter verifies defeat/closure, not win-rate balance.
	for unused in range(180):
		if screen.clock.snapshot().result!="ongoing": break
		if 0 in screen.clock.awaiting_choices():
			_choose("wait")
			await _click(screen.commit_button)
		else:
			await _click(screen.next_button)
	_check(screen.clock.snapshot().result=="enemy_victory","한 교전의 패배·종료 연결")
	_check(screen.commit_button.disabled and screen.next_button.disabled,"종료 뒤 입력 비활성")
	await _capture("03_산적_승리")
	await _click(screen.restart_button)
	_check(screen.clock.snapshot().result=="ongoing","승패 후 재시작")
	print("MOUNTAIN_SMOKE: %d checks, %d failures" % [checks,failures.size()])
	var output := OS.get_environment("GARA_CAPTURE_DIR")
	if not output.is_empty():
		var file := FileAccess.open(output.path_join("smoke-result.json"),FileAccess.WRITE)
		file.store_string(JSON.stringify({"checks":checks,"failures":failures,"display":DisplayServer.get_name(),"godot":Engine.get_version_info().string,"stage_ratio":screen.stage_panel.size/screen.get_viewport_rect().size},"  "))
	screen.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
