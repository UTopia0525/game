extends SceneTree
var checks := 0
var failures: Array = []

func _initialize() -> void:
	_run.call_deferred()

func _check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures.append(message)
		push_error(message)

func _run() -> void:
	var screen = load("res://mountain/main.tscn").instantiate()
	root.add_child(screen)
	await process_frame
	await process_frame
	var board = screen.board
	var output := OS.get_environment("GARA_JUMP_CAPTURE")
	if not output.is_empty(): DirAccess.make_dir_recursive_absolute(output)
	# Explicit preview input, not a new AI or stat/weapon preset.
	screen.clock.setup([screen._actor(Vector2i(2,2),"refined_sword"),screen._actor(Vector2i(5,2),"thickback_saber")],Vector2i(7,5))
	board.view = {}
	board._seen_events = 0
	board._jump_tracks = [{},{}]
	screen._event_cursor = 0
	screen._history = []
	screen.clock.commit_action(1,"basic_defense",Vector2i.LEFT)
	screen.clock.commit_action(0,"move",Vector2i.RIGHT)
	screen.clock.advance_next()
	screen._collect_events()
	screen.refresh_view()
	_check(not board.is_motion_busy(),"출수 전 점프 없음")
	if DisplayServer.get_name()!="headless" and not output.is_empty():
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_png(output.path_join("scene_before.png"))
	screen.clock.advance_next()
	screen._collect_events()
	screen.refresh_view()
	_check(board.is_jumping(0),"실제 이동 사건으로 점프 시작")
	_check(screen.clock.snapshot().units[0].position==Vector2i(3,2),"논리 이동은 엔진에서 완료")
	_check(is_equal_approx(screen.clock.snapshot().time_t,2.901),"기존 이동 출수3T×기민 보정 유지")
	var fixed: Dictionary = screen.clock.snapshot()
	var start: Vector2 = board.cell_center(Vector2i(2,2))
	var end: Vector2 = board.cell_center(Vector2i(3,2))
	var sample: Dictionary = board.jump_sample(0,0)
	_check(sample.ground.is_equal_approx(start) and sample.lift==0,"준비 자세는 출발 지면")
	var apex: Dictionary = board.jump_sample(0,board.jump_anticipation+board.jump_flight*0.5)
	_check(apex.ground.is_equal_approx((start+end)*0.5) and apex.lift>0,"공중 정점과 지면 그림자 분리")
	_check(apex.pose==1,"낮은 이동에서는 과한 무릎 접기 미사용")
	_check(apex.lift<board._cell_size().y*1.15*0.5,"기존 큰 도약보다 정점 높이 절반 미만")
	_check(board.jump_anticipation+board.jump_flight+board.jump_landing<0.82,"기존보다 짧은 표시 시간")
	var landed: Dictionary = board.jump_sample(0,board.jump_anticipation+board.jump_flight)
	_check(landed.ground.is_equal_approx(end) and landed.lift==0,"목표 칸 중심 착지")
	_check(landed.pose==3,"착지 자세")
	_check(board.jump_sample(0,board.jump_anticipation+board.jump_flight+board.jump_landing*0.8).pose==1,"착지 뒤 일어서기 연결")
	_check(not board._should_breathe(0),"점프 중 호흡 중단")
	_check(screen.commit_button.disabled and screen.next_button.disabled,"연출 중 중복 명령 방지")
	screen.step_event()
	screen.commit_selected()
	_check(screen.clock.snapshot()==fixed,"연출 중 추가 사건·비용·피해 없음")
	board.set_process(false)
	board._breathing_blend = [0.0,0.0]
	var began: float = board._jump_tracks[0].started
	var duration: float = board.jump_anticipation+board.jump_flight+board.jump_landing
	var capture_rect := Rect2i()
	for frame in range(25):
		var elapsed: float = duration*frame/24.0
		if frame==24: elapsed += 0.0001
		board._breathing_time = began+elapsed
		board._process(0.0)
		_check(screen.clock.snapshot()==fixed,"연출 시간은 논리 상태를 바꾸지 않음")
		if DisplayServer.get_name()!="headless" and not output.is_empty():
			await RenderingServer.frame_post_draw
			var image: Image = root.get_texture().get_image()
			var ratio: Vector2 = Vector2(image.get_size())/screen.size
			# Same framing as v4, preserving displayed character scale in comparison.
			var reference_height: float = board._cell_size().y*1.15
			var top_left: Vector2 = board.global_position+start-Vector2(150,board._half_tile()*3.6+reference_height+24)
			var area := Rect2i(top_left*ratio,Vector2(end.x-start.x+300,board._half_tile()*3.6+reference_height+92)*ratio)
			capture_rect = area
			_check(image.get_region(area).save_png(output.path_join("jump_%02d.png" % frame))==OK,"이동 시안 프레임 저장")
			if frame in [0,12,24]: image.save_png(output.path_join("scene_%02d.png" % frame))
	_check(not board.is_motion_busy(),"착지 후 연출 종료")
	_check(board.marker_center(0).is_equal_approx(end),"최종 표시 기준점은 실제 칸")
	board.set_process(true)
	screen.end_trial()
	await process_frame
	await process_frame
	_check(not board.is_motion_busy(),"교전 종료 시 예약 이동 제거")
	screen.restart_scenario(0)
	await process_frame
	await process_frame
	_check(screen.clock.snapshot().time_ticks==0 and not board.is_motion_busy(),"재시작 후 이전 이동 제거")
	screen.action_picker.select(screen.ACTION_IDS.find("basic_attack"))
	screen.commit_selected()
	await process_frame
	await process_frame
	screen.step_event()
	await process_frame
	await process_frame
	_check(board.is_jumping(1),"산적의 실제 이동도 같은 연출")
	screen.end_trial()
	await process_frame
	await process_frame
	_check(not board.is_motion_busy(),"공중에서 종료해도 잔여 점프 제거")
	print("JUMP_SMOKE: %d checks, %d failures" % [checks,failures.size()])
	if not output.is_empty():
		var file := FileAccess.open(output.path_join("jump-result.json"),FileAccess.WRITE)
		file.store_string(JSON.stringify({"checks":checks,"failures":failures,"display":DisplayServer.get_name(),"combat_T":fixed.time_t,"duration":duration,"height":apex.lift,"cell_width":end.x-start.x,"capture_rect":{"x":capture_rect.position.x,"y":capture_rect.position.y,"width":capture_rect.size.x,"height":capture_rect.size.y}},"  "))
	screen.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
