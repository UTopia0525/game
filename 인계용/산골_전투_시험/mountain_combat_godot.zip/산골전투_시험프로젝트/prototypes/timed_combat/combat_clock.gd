extends RefCounted
## Pure two-actor clock; no Node, Timer, production data, AI, save or UI dependencies.
const Rules = preload("res://prototypes/timed_combat/combat_rules.gd")
var _units: Array = []
var _size = Vector2i(7, 5)
var _now: int = 0
var _sequence: int = 0
var _result: String = "uninitialized"
var _events: Array = []

func setup(combatants: Array, board_size: Vector2i = Vector2i(7, 5)) -> Dictionary:
	if combatants.size() != 2 or board_size.x < 1 or board_size.y < 1:
		return _failure("invalid_setup")
	var prepared: Array = []
	for source in combatants:
		if not source is Dictionary or not source.get("stats") is Dictionary:
			return _failure("invalid_stats")
		for key in Rules.STAT_KEYS:
			var value = source.stats.get(key)
			if not value is int or value < 0 or value > 200:
				return _failure("invalid_stats")
		var weapon = source.get("weapon", "none")
		var position = source.get("position")
		var skills = source.get("skills", [])
		if not weapon is String or not Rules.WEAPONS.has(weapon):
			return _failure("unsupported_weapon")
		if not position is Vector2i or not Rules.inside(position, board_size):
			return _failure("invalid_position")
		if not skills is Array:
			return _failure("invalid_skills")
		for id in skills:
			if not id is String or not Rules.ACTIONS.has(id):
				return _failure("unsupported_action")
		var maximum: int = Rules.max_health(source.stats)
		prepared.append({"stats":source.stats.duplicate(true), "weapon":weapon, "position":position,
			"skills":skills.duplicate(), "hp":maximum, "max_hp":maximum,
			"qi_units":int(source.stats.inner) * Rules.QI_SCALE, "phase":"ready", "action":{}})
	_units = prepared
	_size = board_size
	_now = 0
	_sequence = 0
	_result = "ongoing"
	_events = []
	return {"ok":true}

func snapshot() -> Dictionary:
	var public_units: Array = _units.duplicate(true)
	for unit in public_units:
		unit.qi = float(unit.qi_units) / Rules.QI_SCALE
	return {"time_t":float(_now) / Rules.TIME_SCALE, "time_ticks":_now,
		"board_size":_size, "result":_result, "units":public_units, "events":_events.duplicate(true)}

func awaiting_choices() -> Array:
	var result: Array = []
	if _result == "ongoing":
		for index in range(2):
			if _units[index].phase == "ready":
				result.append(index)
	return result

func preview(index: int, id: String, facing: Vector2i) -> Dictionary:
	if _result != "ongoing" or index < 0 or index > 1:
		return _failure("inactive")
	var unit: Dictionary = _units[index]
	if unit.phase != "ready":
		return _failure("not_ready")
	if not Rules.ACTIONS.has(id):
		return _failure("unsupported_action")
	if facing not in Rules.DIRECTIONS:
		return _failure("invalid_facing")
	if id not in Rules.BASIC and id not in unit.skills:
		return _failure("not_learned")
	var data: Dictionary = Rules.ACTIONS[id]
	if data.style != "any" and data.style != Rules.WEAPONS[unit.weapon].style:
		return _failure("wrong_weapon")
	var cost: int = Rules.qi_cost(id, unit.weapon)
	if unit.qi_units < cost * Rules.QI_SCALE:
		return _failure("insufficient_qi")
	if int(data.get("advance", 0)) > 0 and not Rules.inside(unit.position + facing * int(data.advance), _size):
		return _failure("outside_board")
	var cast: int = Rules.duration_ticks(int(data.cast), int(unit.stats.agility))
	var recovery: int = Rules.duration_ticks(int(data.recovery), int(unit.stats.agility))
	return {"ok":true, "id":id, "name":data.name, "facing":facing, "cost":cost,
		"raw":Rules.raw_damage(id, unit.stats), "impact_tick":_now + cast,
		"end_tick":_now + cast + recovery,
		"cells":Rules.footprint(id, unit.position, facing, _size),
		"motion":Rules.geometry(id, unit.position, facing, _size)}

func commit_action(index: int, id: String, facing: Vector2i) -> Dictionary:
	var plan: Dictionary = preview(index, id, facing)
	if not plan.ok:
		return plan
	# At a shared decision boundary the enemy commits before player input.
	if index == 0 and _units[1].phase == "ready":
		return _failure("enemy_choice_required")
	_sequence += 1
	plan.token = _sequence
	plan.start_tick = _now
	_units[index].qi_units -= int(plan.cost) * Rules.QI_SCALE
	_units[index].action = plan.duplicate(true)
	_units[index].phase = "windup"
	_record("started", index, {"id":id, "token":_sequence})
	return {"ok":true, "token":_sequence}

func enemy_announcement() -> Dictionary:
	if _result != "ongoing" or _units[1].action.is_empty():
		return {}
	var action: Dictionary = _units[1].action
	# Exact technique is public by latest user instruction. No private mutable plan.
	return {"actor":1, "id":action.id, "name":action.name, "phase":_units[1].phase,
		"facing":action.facing, "relative_cells":Rules.ACTIONS[action.id].cells.duplicate(),
		"cells":Rules.footprint(action.id, _units[1].position, action.facing, _size) if _units[1].phase == "windup" else [],
		"path":Rules.geometry(action.id, _units[1].position, action.facing, _size).path if _units[1].phase == "windup" else [],
		"impact_t":float(action.impact_tick) / Rules.TIME_SCALE,
		"ready_t":float(action.end_tick) / Rules.TIME_SCALE}

func advance_next() -> Dictionary:
	if _result != "ongoing":
		return _failure("inactive")
	if not awaiting_choices().is_empty():
		return _failure("choice_required")
	var next_tick: int = 9223372036854775807
	for unit in _units:
		if unit.phase == "windup":
			next_tick = mini(next_tick, int(unit.action.impact_tick))
		elif unit.phase == "recovery":
			next_tick = mini(next_tick, int(unit.action.end_tick))
	var first_event: int = _events.size()
	var elapsed: int = next_tick - _now
	for unit in _units:
		# qi_units = qi * 10000; inner/10 * elapsed/1000 is exact here.
		unit.qi_units = mini(Rules.QI_CAP, int(unit.qi_units) + int(unit.stats.inner) * elapsed)
	_now = next_tick
	var impacts: Array = []
	for index in range(2):
		var unit: Dictionary = _units[index]
		if unit.phase == "recovery" and unit.action.end_tick == _now:
			_record("ready", index, {"token":unit.action.token})
			unit.phase = "ready"
			unit.action = {}
		elif unit.phase == "windup" and unit.action.impact_tick == _now:
			unit.phase = "recovery"
			impacts.append(index)
	# Same-time movement precedes all attack footprints.
	var motions: Dictionary = {}
	for index in impacts:
		var unit: Dictionary = _units[index]
		motions[index] = Rules.geometry(unit.action.id, unit.position, unit.action.facing, _size)
	for index in impacts:
		var unit: Dictionary = _units[index]
		if unit.position != motions[index].caster:
			unit.position = motions[index].caster
			_record("moved", index, {"position":unit.position})
	var damage: Array = [0, 0]
	var forces: Array = [[], []]
	for index in impacts:
		var unit: Dictionary = _units[index]
		var action: Dictionary = unit.action
		var data: Dictionary = Rules.ACTIONS[action.id]
		var target: int = 1 - index
		var cells: Array = Rules.attack_cells(action.id, unit.position, action.facing, _size, motions[index].path)
		var hit: bool = _units[target].position in cells
		var dealt: int = 0
		if hit:
			dealt = Rules.damage(action.id, unit.stats, unit.weapon, _units[target].weapon, _guard(target))
			damage[target] += dealt
			var direction: Vector2i = Rules.push_vector(action.id, unit.position, _units[target].position, action.facing)
			if direction != Vector2i.ZERO:
				forces[target].append({"source":index, "direction":direction, "steps":int(data.push)})
		if int(data.get("retreat", 0)) > 0:
			forces[index].append({"source":index, "direction":-action.facing, "steps":int(data.retreat)})
		var restored: int = int(data.get("restore_inner", 0)) * int(unit.stats.inner) * Rules.QI_SCALE
		unit.qi_units = mini(Rules.QI_CAP, int(unit.qi_units) + restored)
		_record("effect", index, {"id":action.id, "token":action.token, "hit":hit, "damage":dealt,
			"attack":Rules.is_attack(action.id), "cells":cells, "path":motions[index].path})
	for index in range(2):
		_units[index].hp = maxi(0, int(_units[index].hp) - int(damage[index]))
	_resolve_forces(forces)
	for index in range(2):
		if _units[index].hp == 0:
			_units[index].phase = "dead"
			_units[index].action = {}
			_record("dead", index, {})
	if _units[0].hp == 0 or _units[1].hp == 0:
		_result = "draw" if _units[0].hp == 0 and _units[1].hp == 0 else ("player_victory" if _units[1].hp == 0 else "enemy_victory")
		for unit in _units:
			unit.action = {}
		_record("finished", -1, {"result":_result})
	return {"ok":true, "time_t":float(_now) / Rules.TIME_SCALE,
		"events":_events.slice(first_event).duplicate(true), "result":_result}

func cancel_battle() -> void:
	if _result != "ongoing":
		return
	_result = "cancelled"
	for unit in _units:
		unit.action = {}
	_record("cancelled", -1, {})

func _resolve_forces(forces: Array) -> void:
	# All destinations derive from the same post-hit state; occupancy never blocks.
	var destinations: Dictionary = {}
	for index in range(2):
		if _units[index].hp == 0: continue
		var candidates: Array = []
		for force in forces[index]:
			if _units[force.source].hp == 0: continue
			var point: Vector2i = _units[index].position
			for step in range(force.steps):
				if not Rules.inside(point + force.direction, _size): break
				point += force.direction
			if point not in candidates: candidates.append(point)
		if candidates.size() == 1:
			destinations[index] = candidates[0]
		elif candidates.size() > 1:
			_record("movement_conflict", index, {})
	for index in destinations:
		if _units[index].position != destinations[index]:
			_units[index].position = destinations[index]
			_record("forced_move", index, {"position":destinations[index]})

func _guard(index: int) -> int:
	var unit: Dictionary = _units[index]
	if unit.phase != "recovery" or unit.action.is_empty():
		return 0
	return int(Rules.ACTIONS[unit.action.id].get("guard", 0))

func _record(kind: String, actor: int, details: Dictionary) -> void:
	var event: Dictionary = details.duplicate(true)
	event.kind = kind
	event.actor = actor
	event.time_ticks = _now
	_events.append(event)

func _failure(reason: String) -> Dictionary:
	return {"ok":false, "reason":reason}
