extends Control
## Presentation only: positions and highlights come from clock/rule query results.
const PLAYER_COLOR = Color("67d6d0")
const ENEMY_COLOR = Color("f5a86a")
var view: Dictionary = {}
var player_cells: Array = []
var enemy_cells: Array = []
var move_cell: Array = []
var facings: Array = [Vector2i.RIGHT, Vector2i.LEFT]

func _ready() -> void:
	custom_minimum_size = Vector2(440, 300)
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func present(state: Dictionary, selected: Array, announced: Array, movement: Array, last_facings: Array) -> void:
	view = state.duplicate(true)
	player_cells = selected.duplicate()
	enemy_cells = announced.duplicate()
	move_cell = movement.duplicate()
	facings = last_facings.duplicate()
	queue_redraw()

func cell_rect(point: Vector2i) -> Rect2:
	var grid: Vector2i = view.get("board_size", Vector2i(7, 5))
	var unit: float = minf((size.x - 52.0) / grid.x, (size.y - 44.0) / grid.y)
	var origin: Vector2 = (size - Vector2(grid) * unit) * 0.5
	return Rect2(origin + Vector2(point) * unit, Vector2.ONE * unit)

func marker_center(index: int) -> Vector2:
	# Both share the logical cell; split the two symbols only inside that cell.
	var point: Vector2i = view.units[index].position
	var rect: Rect2 = cell_rect(point)
	var shift: float = 0.0
	if point == view.units[1-index].position:
		shift = rect.size.x * (-0.20 if index == 0 else 0.20)
	return rect.get_center() + Vector2(shift, 0)

func _draw() -> void:
	if view.is_empty():
		return
	var font: Font = get_theme_default_font()
	var grid: Vector2i = view.board_size
	for y in range(grid.y):
		for x in range(grid.x):
			var point = Vector2i(x, y)
			var rect: Rect2 = cell_rect(point)
			draw_rect(rect, Color("1d3039") if (x+y)%2 == 0 else Color("203640"))
			if point in player_cells:
				draw_rect(rect.grow(-3), Color(0.25, 0.85, 0.80, 0.25))
			if point in enemy_cells:
				draw_rect(rect.grow(-6), ENEMY_COLOR, false, 3)
			if point in move_cell:
				draw_rect(rect.grow(-9), PLAYER_COLOR, false, 2)
			draw_rect(rect, Color("58717c"), false, 1)
			if y == 0:
				draw_string(font, Vector2(rect.get_center().x - 5, rect.position.y - 6), str(x), HORIZONTAL_ALIGNMENT_LEFT, -1, 14)
			if x == 0:
				draw_string(font, rect.position + Vector2(-18, rect.size.y * 0.56), str(y), HORIZONTAL_ALIGNMENT_LEFT, -1, 14)
	for index in range(view.units.size()):
		var actor: Dictionary = view.units[index]
		var center: Vector2 = marker_center(index)
		var radius: float = cell_rect(actor.position).size.x * 0.15
		var color: Color = PLAYER_COLOR if index == 0 else ENEMY_COLOR
		if actor.hp == 0:
			color = Color("8a9296")
		draw_circle(center, radius + 2, Color("0c171e"))
		if index == 0:
			draw_circle(center, radius, color)
		else:
			draw_rect(Rect2(center - Vector2.ONE * radius, Vector2.ONE * radius * 2), color)
		var facing: Vector2i = facings[index]
		if not actor.action.is_empty():
			facing = actor.action.facing
		var end: Vector2 = center + Vector2(facing) * radius * 2.0
		draw_line(center, end, color, 3)
		var side = Vector2(-facing.y, facing.x)
		draw_line(end, end - Vector2(facing) * 6 + side * 4, color, 2)
		draw_line(end, end - Vector2(facing) * 6 - side * 4, color, 2)
		draw_string(font, center + Vector2(-8, radius + 18), "도" if index == 0 else "적", HORIZONTAL_ALIGNMENT_LEFT, -1, 15, color)
