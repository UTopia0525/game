extends RefCounted
## Isolated GARA v2.1 G/H rules. Never reads or changes the production catalog.
## Basic-action timings are the user's approved pre-implementation decision set.
const TIME_SCALE = 1000
const QI_SCALE = 10000
const QI_CAP = 500 * QI_SCALE
const DIRECTIONS = [Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT, Vector2i.UP]
const STAT_KEYS = ["strength", "agility", "constitution", "inner", "insight"]
static var CATALOG: Dictionary = _load_catalog()
static var WEAPONS: Dictionary = _index(CATALOG.weapons)
static var BASIC: Array = _index(CATALOG.basic_actions).keys()
static var MARTIAL_IDS: Array = _index(CATALOG.martial_arts).keys()
static var ACTIONS: Dictionary = _index(CATALOG.basic_actions + CATALOG.martial_arts)

static func _load_catalog() -> Dictionary:
	var value = JSON.parse_string(FileAccess.get_file_as_string("res://prototypes/timed_combat/combat_catalog.json"))
	var errors: Array = catalog_errors(value)
	if not errors.is_empty():
		push_error("TIMED_CATALOG: " + "; ".join(errors))
		return {"weapons":[], "basic_actions":[], "martial_arts":[]}
	return value

static func _index(rows: Array) -> Dictionary:
	var result: Dictionary = {}
	for row in rows:
		var data: Dictionary = row.duplicate(true)
		for key in ["cast", "recovery", "cost", "base", "strength", "inner", "guard", "restore_inner", "advance", "retreat", "dash", "push", "attack", "defense", "qi"]:
			if data.has(key): data[key] = int(data[key])
		if data.has("cells"):
			data.cells = data.cells.map(func(cell): return int(cell))
		result[data.id] = data
	return result

static func catalog_errors(value) -> Array:
	var errors: Array = []
	if not value is Dictionary or value.get("schema") != 1:
		return ["지원하지 않는 데이터 형식"]
	var ids: Array = []
	for section in ["basic_actions", "martial_arts", "weapons"]:
		if not value.get(section) is Array:
			errors.append(section + ": 목록 필요")
			continue
		for row in value[section]:
			if not row is Dictionary or not row.get("id") is String or not row.get("name") is String:
				errors.append(section + ": ID·이름 필요")
				continue
			var id: String = row.id
			if id.is_empty() or id in ids: errors.append("빈 ID 또는 중복 ID: " + id)
			ids.append(id)
			if row.get("style", "") not in ["any", "sword", "saber", "spear", "none"]:
				errors.append(id + ": 무기 유형 오류")
			if section == "weapons":
				for key in ["attack", "defense", "qi"]:
					if not _whole(row.get(key)): errors.append(id + ": 장비 수치 오류")
				if _number(row.get("defense", 0)) > 100 or _number(row.get("qi", 100)) > 100:
					errors.append(id + ": 장비 백분율 오류")
				continue
			var fields: Array = ["id","name","grade","style","cast","recovery","cost","cells","base","strength","inner","guard","restore_inner","advance","retreat","dash","push","push_mode","source","decisions"]
			for key in row:
				if key not in fields: errors.append(id + ": 지원하지 않는 필드 " + str(key))
			if row.get("grade", "") not in (["basic"] if section == "basic_actions" else ["intro", "low"]):
				errors.append(id + ": 등급 오류")
			if not row.get("source") is String: errors.append(id + ": 출처 필요")
			for key in ["cast", "recovery", "cost"]:
				if not _whole(row.get(key)): errors.append(id + ": " + key + " 수치 오류")
			for key in ["base","strength","inner","guard","restore_inner","advance","retreat","dash","push"]:
				if not _whole(row.get(key, 0)): errors.append(id + ": " + key + " 수치 오류")
			if _number(row.get("cast", 0)) + _number(row.get("recovery", 0)) <= 0 or _number(row.get("recovery", 0)) <= 0:
				errors.append(id + ": 회수 시간이 필요함")
			if _number(row.get("guard", 0)) > 100: errors.append(id + ": 수세 백분율 오류")
			if row.get("push_mode", "none") not in ["none", "radial", "forward", "near_column"]:
				errors.append(id + ": 밀치기 유형 오류")
			if _number(row.get("push", 0)) > 0 and row.get("push_mode", "none") == "none": errors.append(id + ": 밀치기 방향 필요")
			if _number(row.get("advance", 0)) > 0 and _number(row.get("dash", 0)) > 0: errors.append(id + ": 전진·돌진 중복")
			if not row.get("cells") is Array:
				errors.append(id + ": 상대 범위 필요")
			else:
				var seen: Array = []
				for cell in row.cells:
					if not _whole(cell) or float(cell) < 1 or float(cell) > 12 or cell in seen:
						errors.append(id + ": 범위 번호 오류 또는 중복")
					seen.append(cell)
	return errors

static func _number(value) -> float:
	return float(value) if (value is int or value is float) and is_finite(float(value)) else 0.0

static func _whole(value) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0 and float(value) == floorf(float(value))

static func ids_for_weapon(weapon: String) -> Array:
	var ids: Array = []
	if not WEAPONS.has(weapon): return ids
	for id in MARTIAL_IDS:
		if ACTIONS[id].style == WEAPONS[weapon].style: ids.append(id)
	return ids

static func all_action_ids() -> Array:
	return ["basic_attack"] + MARTIAL_IDS + ["basic_defense", "move", "wait", "breathe"]

static func is_attack(id: String) -> bool:
	return int(ACTIONS[id].get("base", 0)) + int(ACTIONS[id].get("strength", 0)) + int(ACTIONS[id].get("inner", 0)) > 0

static func max_health(stats: Dictionary) -> int:
	return 200 + int(stats.constitution) * 10

static func duration_ticks(base_t: int, agility: int) -> int:
	# Exact for the supported integer T / integer stat catalog; no frame rounding.
	return base_t * (TIME_SCALE - agility)

static func raw_damage(id: String, stats: Dictionary) -> int:
	var data: Dictionary = ACTIONS[id]
	return int(data.get("base", 0)) + int(data.get("strength", 0)) * int(stats.strength) + int(data.get("inner", 0)) * int(stats.inner)

static func qi_cost(id: String, weapon: String) -> int:
	return cost_after_percent(int(ACTIONS[id].cost), int(WEAPONS[weapon].qi))

@warning_ignore("integer_division")
static func cost_after_percent(base_cost: int, remaining_percent: int) -> int:
	var numerator: int = base_cost * remaining_percent
	return (numerator + 99) / 100

@warning_ignore("integer_division")
static func damage(id: String, stats: Dictionary, weapon: String, defender_weapon: String, guard: int) -> int:
	# Multiply independent effects and floor once. Constitution is never consulted.
	var numerator: int = raw_damage(id, stats) * int(WEAPONS[weapon].attack) * (100 - int(WEAPONS[defender_weapon].defense)) * (100 - guard)
	return numerator / 1000000

@warning_ignore("integer_division")
static func offset(cell: int) -> Vector2i:
	return Vector2i((cell - 1) % 4 - 1, (cell - 1) / 4 - 1)

static func rotate(value: Vector2i, facing: Vector2i) -> Vector2i:
	return facing * value.x + Vector2i(-facing.y, facing.x) * value.y

static func geometry(id: String, origin: Vector2i, facing: Vector2i, board_size: Vector2i) -> Dictionary:
	var data: Dictionary = ACTIONS[id]
	var caster: Vector2i = origin
	var path: Array = []
	var steps: int = maxi(int(data.get("advance", 0)), int(data.get("dash", 0)))
	for step in range(steps):
		var point: Vector2i = caster + facing
		if not inside(point, board_size): break
		caster = point
		path.append(point)
	return {"caster":caster, "path":path, "cells":attack_cells(id, caster, facing, board_size, path)}

static func footprint(id: String, origin: Vector2i, facing: Vector2i, board_size: Vector2i) -> Array:
	return geometry(id, origin, facing, board_size).cells

static func attack_cells(id: String, caster: Vector2i, facing: Vector2i, board_size: Vector2i, path: Array) -> Array:
	if int(ACTIONS[id].get("dash", 0)) > 0: return path.duplicate()
	var cells: Array = []
	for cell in ACTIONS[id].cells:
		var point: Vector2i = caster + rotate(offset(cell), facing)
		if inside(point, board_size): cells.append(point)
	return cells

static func push_vector(id: String, caster: Vector2i, target: Vector2i, facing: Vector2i) -> Vector2i:
	var data: Dictionary = ACTIONS[id]
	if int(data.get("push", 0)) == 0: return Vector2i.ZERO
	match data.get("push_mode", "none"):
		"radial": return Vector2i(signi(target.x - caster.x), signi(target.y - caster.y))
		"forward": return facing
		"near_column": return facing if (target.x - caster.x) * facing.x + (target.y - caster.y) * facing.y == 1 else Vector2i.ZERO
	return Vector2i.ZERO

static func inside(point: Vector2i, board_size: Vector2i) -> bool:
	return point.x >= 0 and point.y >= 0 and point.x < board_size.x and point.y < board_size.y
