extends Control
## Minimal event-step adapter. All combat decisions/calculations stay in Clock/Rules.
const Clock = preload("res://prototypes/timed_combat/combat_clock.gd")
const Rules = preload("res://prototypes/timed_combat/combat_rules.gd")
const Board = preload("res://prototypes/timed_combat/test_board.gd")
var ACTION_IDS: Array = Rules.all_action_ids()
var WEAPON_IDS: Array = Rules.WEAPONS.keys()
const PHASE_NAMES = {"ready":"선택 대기", "windup":"출수", "recovery":"회수", "dead":"전투불능"}
const RESULT_NAMES = {"ongoing":"진행 중", "player_victory":"도원 승리", "enemy_victory":"적 승리", "draw":"동시 전투불능", "cancelled":"시험 종료"}
const DIRECTION_NAMES = ["오른쪽 →", "아래 ↓", "왼쪽 ←", "위 ↑"]
const REASONS = {"inactive":"교전이 종료되었습니다.", "not_ready":"출수·회수 중에는 다음 행동을 고를 수 없습니다.",
	"insufficient_qi":"내기가 부족합니다. 숨 고르기 등으로 회복하세요.", "wrong_weapon":"현재 장비로 사용할 수 없습니다.",
	"not_learned":"이 시나리오에서 익히지 않은 기술입니다.", "outside_board":"전장 밖으로 이동할 수 없습니다.",
	"enemy_choice_required":"적의 예정 행동 확정이 필요합니다.", "choice_required":"아직 행동을 선택해야 합니다."}
var clock = Clock.new()
var board: Control
var scenario_picker: OptionButton
var action_picker: OptionButton
var direction_picker: OptionButton
var weapon_picker: OptionButton
var loadout_picker: OptionButton
var commit_button: Button
var next_button: Button
var restart_button: Button
var end_button: Button
var time_label: Label
var status_labels: Array = []
var announcement_label: Label
var preview_label: Label
var notice_label: Label
var scenario_label: Label
var log_view: RichTextLabel
var scenario_index: int = 0
var _enemy_steps: Array = []
var _enemy_cursor: int = 0
var _enemy_blocked: String = ""
var _event_cursor: int = 0
var _history: PackedStringArray = []
var _input_locked: bool = false
var _ended: bool = false
var _last_facings: Array = [Vector2i.RIGHT, Vector2i.LEFT]
var _active_loadout: String = "all"

func _ready() -> void:
	_build_ui()
	restart_scenario(0)

func _build_ui() -> void:
	var paper = Theme.new()
	var body_font = FontFile.new()
	if body_font.load_dynamic_font("res://assets/fonts/NanumMyeongjo-Regular.ttf") == OK:
		paper.default_font = body_font
	paper.default_font_size = 17
	theme = paper
	var backdrop = ColorRect.new()
	backdrop.color = Color("101e28")
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(backdrop)
	var margin = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 16)
	add_child(margin)
	var root_box = VBoxContainer.new()
	root_box.add_theme_constant_override("separation", 9)
	margin.add_child(root_box)
	var toolbar = HBoxContainer.new()
	root_box.add_child(toolbar)
	var title: Label = _label(toolbar, "시간축 전투 · 독립 시험")
	var brush = FontFile.new()
	if brush.load_dynamic_font("res://assets/fonts/NanumBrushScript-Regular.ttf") == OK:
		title.add_theme_font_override("font", brush)
	title.add_theme_font_size_override("font_size", 28)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scenario_picker = OptionButton.new()
	for item in ["검 · 예고와 회피", "창 · 회복과 거리", "중첩 · 범위와 수세", "자유 편성 · 무기별"]:
		scenario_picker.add_item(item)
	scenario_picker.item_selected.connect(_on_scenario_selected)
	toolbar.add_child(scenario_picker)
	restart_button = _button(toolbar, "재시작", func(): restart_scenario(scenario_index))
	end_button = _button(toolbar, "시험 종료", end_trial)
	scenario_label = _label(root_box, "")
	scenario_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	time_label = _label(root_box, "")
	var status_row = HBoxContainer.new()
	root_box.add_child(status_row)
	for index in range(2):
		var card: Label = _label(status_row, "")
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		card.add_theme_color_override("font_color", Board.PLAYER_COLOR if index == 0 else Board.ENEMY_COLOR)
		status_labels.append(card)
	var middle = HBoxContainer.new()
	middle.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_theme_constant_override("separation", 18)
	root_box.add_child(middle)
	var board_column = VBoxContainer.new()
	board_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	board_column.size_flags_stretch_ratio = 1.4
	middle.add_child(board_column)
	board = Board.new()
	board_column.add_child(board)
	var legend: Label = _label(board_column, "청록 원: 도원 · 주황 사각: 적 | 청록 면: 선택 범위 · 주황 테두리: 적 예고")
	legend.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var side = VBoxContainer.new()
	side.custom_minimum_size.x = 340
	side.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	middle.add_child(side)
	_label(side, "확정된 적 행동 · 미래 예고").add_theme_color_override("font_color", Board.ENEMY_COLOR)
	announcement_label = _label(side, "")
	announcement_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_label(side, "발생한 사건 · 실행 결과")
	log_view = RichTextLabel.new()
	log_view.custom_minimum_size.y = 130
	log_view.size_flags_vertical = Control.SIZE_EXPAND_FILL
	log_view.bbcode_enabled = false
	log_view.scroll_following = true
	log_view.selection_enabled = true
	side.add_child(log_view)
	var choices = HBoxContainer.new()
	root_box.add_child(choices)
	_label(choices, "시험 장비")
	weapon_picker = OptionButton.new()
	for weapon in WEAPON_IDS:
		weapon_picker.add_item(Rules.WEAPONS[weapon].name)
	weapon_picker.select(WEAPON_IDS.find("refined_sword"))
	weapon_picker.item_selected.connect(_on_weapon_selected)
	choices.add_child(weapon_picker)
	_label(choices, "시험 편성")
	loadout_picker = OptionButton.new()
	loadout_picker.item_selected.connect(_on_loadout_selected)
	choices.add_child(loadout_picker)
	_rebuild_loadouts("refined_sword")
	_label(choices, "행동")
	action_picker = OptionButton.new()
	for id in ACTION_IDS:
		action_picker.add_item(Rules.ACTIONS[id].name)
	action_picker.item_selected.connect(func(_item): refresh_view())
	choices.add_child(action_picker)
	_label(choices, "방향")
	direction_picker = OptionButton.new()
	for direction in DIRECTION_NAMES:
		direction_picker.add_item(direction)
	direction_picker.item_selected.connect(func(_item): refresh_view())
	choices.add_child(direction_picker)
	commit_button = _button(choices, "행동 확정", commit_selected)
	next_button = _button(choices, "다음 사건", step_event)
	preview_label = _label(root_box, "")
	preview_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	notice_label = _label(root_box, "")
	notice_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	notice_label.add_theme_color_override("font_color", Color("f0d498"))

func restart_scenario(index: int) -> void:
	if not _enter_command():
		return
	clock.cancel_battle()
	clock = Clock.new()
	scenario_index = clampi(index, 0, 3)
	scenario_picker.select(scenario_index)
	_ended = false
	_enemy_blocked = ""
	_enemy_cursor = 0
	_event_cursor = 0
	_history = []
	_last_facings = [Vector2i.RIGHT, Vector2i.LEFT]
	var first_position = Vector2i(1, 2)
	var second_position = Vector2i(3, 2)
	var weapon: String = "refined_sword"
	_enemy_steps = [{"id":"samjae", "facing":Vector2i.LEFT}, {"id":"breathe", "facing":Vector2i.LEFT},
		{"id":"basic_attack", "facing":Vector2i.LEFT}, {"id":"basic_defense", "facing":Vector2i.LEFT}]
	if scenario_index == 1:
		weapon = "balanced_spear"
		first_position = Vector2i(1, 2)
		_enemy_steps = [{"id":"breathe", "facing":Vector2i.LEFT}, {"id":"basic_defense", "facing":Vector2i.LEFT}, {"id":"wait", "facing":Vector2i.LEFT}]
	elif scenario_index == 2:
		first_position = Vector2i(3, 2)
		_enemy_steps = [{"id":"samjae", "facing":Vector2i.LEFT}, {"id":"basic_defense", "facing":Vector2i.LEFT},
			{"id":"breathe", "facing":Vector2i.LEFT}, {"id":"basic_attack", "facing":Vector2i.LEFT}]
	elif scenario_index == 3:
		weapon = WEAPON_IDS[weapon_picker.selected]
		first_position = Vector2i(2, 2)
		second_position = Vector2i(4, 2)
		_enemy_steps = [{"id":"breathe", "facing":Vector2i.LEFT}, {"id":"basic_defense", "facing":Vector2i.LEFT}, {"id":"wait", "facing":Vector2i.LEFT}]
	weapon_picker.disabled = scenario_index != 3
	loadout_picker.disabled = scenario_index != 3
	if scenario_index != 3:
		weapon_picker.select(WEAPON_IDS.find(weapon))
		_rebuild_loadouts(weapon)
	var player: Dictionary = _actor(first_position, weapon)
	_active_loadout = "all"
	if scenario_index == 3:
		var preset: String = loadout_picker.get_selected_metadata()
		_active_loadout = preset
		if preset == "basic_only": player.skills = []
		elif preset != "all": player.skills = [preset]
	var setup: Dictionary = clock.setup([player, _actor(second_position, "refined_sword")], Vector2i(7,5))
	if not setup.ok:
		_enemy_blocked = setup.reason
	var notes: Array = [
		"검: 적은 삼재 → 숨 고르기 → 기본공격 → 방어를 반복. 거리2에서 기본공격·삼재를 비교하고, 위·아래·왼쪽 이동으로 피하세요.",
		"창: 적은 숨 고르기 → 방어 → 대기를 반복. 시작 내기34로 관풍81은 불가. 숨 고르기 후 거리2 공격을 확인하세요.",
		"중첩: 적은 삼재 → 방어 → 숨 고르기 → 기본공격을 반복. 겹친 칸은 명시 범위 밖입니다. 이동 후 비교하세요.",
		"자유 편성: 시험 장비를 바꾸면 새 교전으로 시작. 적은 숨 고르기 → 방어 → 대기 고정. 습득·저장과 무관합니다."]
	var hand: bool = weapon == "none"
	scenario_label.text = notes[scenario_index] + "\n총합150 · 체력530 · 도원 %s · 시작 내기%d · 장애물 없음" % ["34/33/33/38/12" if hand else "38/33/33/34/12", 38 if hand else 34]
	action_picker.select(ACTION_IDS.find("gwanpung" if scenario_index == 1 else (player.skills[0] if not player.skills.is_empty() else "basic_attack")))
	direction_picker.select(0)
	_ensure_enemy_plan()
	_collect_events()
	refresh_view()

func _actor(position: Vector2i, weapon: String) -> Dictionary:
	return {"stats":{"strength":38,"agility":33,"constitution":33,"inner":34,"insight":12},
		"position":position, "weapon":weapon, "skills":Rules.ids_for_weapon(weapon)} if weapon != "none" else {
		"stats":{"strength":34,"agility":33,"constitution":33,"inner":38,"insight":12}, "position":position, "weapon":weapon, "skills":Rules.ids_for_weapon(weapon)}

func _rebuild_loadouts(weapon: String) -> void:
	loadout_picker.clear()
	loadout_picker.add_item("해당 무공 전체")
	loadout_picker.set_item_metadata(0, "all")
	loadout_picker.add_item("기본 행동만")
	loadout_picker.set_item_metadata(1, "basic_only")
	for id in Rules.ids_for_weapon(weapon):
		loadout_picker.add_item(Rules.ACTIONS[id].name + "만")
		loadout_picker.set_item_metadata(loadout_picker.item_count - 1, id)
	loadout_picker.select(0)

func _on_weapon_selected(index: int) -> void:
	if _input_locked:
		weapon_picker.select(WEAPON_IDS.find(clock.snapshot().units[0].weapon))
		return
	_rebuild_loadouts(WEAPON_IDS[index])
	restart_scenario(3)

func _on_loadout_selected(_index: int) -> void:
	if _input_locked:
		for index in range(loadout_picker.item_count):
			if loadout_picker.get_item_metadata(index) == _active_loadout:
				loadout_picker.select(index)
		return
	restart_scenario(3)

func _ensure_enemy_plan() -> void:
	if _ended or 1 not in clock.awaiting_choices() or not _enemy_blocked.is_empty():
		return
	var choice: Dictionary = _enemy_steps[_enemy_cursor % _enemy_steps.size()]
	var result: Dictionary = clock.commit_action(1, choice.id, choice.facing)
	if result.ok:
		_enemy_cursor += 1
		_last_facings[1] = choice.facing
	else:
		_enemy_blocked = "%s：%s" % [Rules.ACTIONS.get(choice.id, {"name":choice.id}).name, _reason(result.reason)]
		_history.append("적 예정 행동 불가 · " + _enemy_blocked + "（대체하지 않음）")

func commit_selected() -> void:
	if not _enter_command():
		return
	if _ended or not _enemy_blocked.is_empty():
		return
	var result: Dictionary = clock.commit_action(0, ACTION_IDS[action_picker.selected], Rules.DIRECTIONS[direction_picker.selected])
	if not result.ok:
		_history.append("행동 확정 불가 · " + _reason(result.reason))
	else:
		_last_facings[0] = Rules.DIRECTIONS[direction_picker.selected]
	_collect_events()
	refresh_view()

func step_event() -> void:
	if not _enter_command():
		return
	if _ended or not _enemy_blocked.is_empty():
		return
	var before: Dictionary = clock.snapshot()
	var result: Dictionary = clock.advance_next()
	if result.ok:
		_collect_events()
		var after: Dictionary = clock.snapshot()
		for index in range(2):
			var recovered: float = after.units[index].qi - before.units[index].qi
			if recovered > 0:
				_history.append("T %.3f · %s 내기 회복 +%.4f（자연·행동 효과 합계）" % [after.time_t, _actor_name(index), recovered])
		_ensure_enemy_plan()
		_collect_events()
	else:
		_history.append("시간 진행 불가 · " + _reason(result.reason))
	refresh_view()

func end_trial() -> void:
	if not _enter_command():
		return
	clock.cancel_battle()
	_ended = true
	_collect_events()
	refresh_view()

func refresh_view() -> void:
	var state: Dictionary = clock.snapshot()
	if state.units.size() != 2:
		return
	var ongoing: bool = state.result == "ongoing" and not _ended
	time_label.text = "논리 시간 T %.3f · %s · 선택/확정만으로 시간은 흐르지 않습니다" % [state.time_t, RESULT_NAMES.get(state.result, state.result)]
	for index in range(2):
		var unit: Dictionary = state.units[index]
		var action_text: String = ""
		if not unit.action.is_empty():
			action_text = "\n%s · %s · 발동 %.3fT / 다음 선택 %.3fT" % [unit.action.name, _direction(unit.action.facing), float(unit.action.impact_tick)/Rules.TIME_SCALE, float(unit.action.end_tick)/Rules.TIME_SCALE]
		var phase_text: String = PHASE_NAMES[unit.phase] if ongoing else ("전투불능" if unit.hp == 0 else "교전 종료")
		status_labels[index].text = "%s · HP %d/%d · 내기 %.4f/500\n%s · %s · 위치(%d,%d)%s" % [_actor_name(index), unit.hp, unit.max_hp, unit.qi, phase_text, _direction(_last_facings[index]), unit.position.x, unit.position.y, action_text]
	var enemy: Dictionary = clock.enemy_announcement()
	var enemy_cells: Array = []
	if enemy.is_empty():
		announcement_label.text = "진행 중인 적 행동 없음"
	else:
		enemy_cells = enemy.cells if enemy.phase == "windup" else []
		var enemy_phase: String = "출수 중 · 앞으로 발동" if enemy.phase == "windup" else "발동 완료 · 회수 중"
		announcement_label.text = "%s · %s · %s\n발동 %.3fT / 다음 선택 %.3fT\n범위 %s\n공격은 출수 완료 때 실제 위치로 판정" % [enemy.name, _direction(enemy.facing), enemy_phase, enemy.impact_t, enemy.ready_t, _cells_text(enemy.cells)]
	var id: String = ACTION_IDS[action_picker.selected]
	var facing: Vector2i = Rules.DIRECTIONS[direction_picker.selected]
	var preview: Dictionary = clock.preview(0, id, facing)
	var geometry: Dictionary = Rules.geometry(id, state.units[0].position, facing, state.board_size) if ongoing and state.units[0].phase in ["ready", "windup"] else {"cells":[],"path":[]}
	var selected_cells: Array = geometry.cells
	var movement: Array = geometry.path
	var data: Dictionary = Rules.ACTIONS[id]
	preview_label.text = "선택: %s · 내기 %d · 기준 출수/회수 %d/%dT · 범위 %s" % [data.name, Rules.qi_cost(id, state.units[0].weapon), data.cast, data.recovery, _cells_text(selected_cells)]
	if not movement.is_empty(): preview_label.text += "\n전진·돌진 경로 " + _cells_text(movement)
	if int(data.get("retreat", 0)) > 0: preview_label.text += " · 후퇴%d" % int(data.retreat)
	if int(data.get("push", 0)) > 0: preview_label.text += " · 밀침%d" % int(data.push)
	if not preview.ok:
		preview_label.text += "\n" + _reason(preview.reason)
	var awaiting: Array = clock.awaiting_choices()
	if not ongoing:
		notice_label.text = "교전이 끝났습니다. 재시작 또는 다른 시나리오를 선택하세요."
	elif not _enemy_blocked.is_empty():
		notice_label.text = "적의 고정 행동 불가 · " + _enemy_blocked + " · 시간 정지 / 재시작 가능"
	elif 0 in awaiting:
		notice_label.text = "적 예고 확인 → 행동과 방향 선택 → 행동 확정. 그다음 ‘다음 사건’을 누르세요."
	else:
		notice_label.text = "행동 확정됨 · ‘다음 사건’ 한 번으로 공통 사건 시각 하나만 진행합니다."
	commit_button.disabled = _input_locked or not ongoing or not _enemy_blocked.is_empty() or not preview.ok or 0 not in awaiting
	next_button.disabled = _input_locked or not ongoing or not _enemy_blocked.is_empty() or not awaiting.is_empty()
	action_picker.disabled = not ongoing or 0 not in awaiting
	direction_picker.disabled = action_picker.disabled
	end_button.disabled = _input_locked or _ended
	board.present(state, selected_cells, enemy_cells, movement, _last_facings)
	log_view.text = "\n".join(_history)

func _collect_events() -> void:
	var events: Array = clock.snapshot().events
	for index in range(_event_cursor, events.size()):
		var event: Dictionary = events[index]
		var text: String = ""
		match event.kind:
			"started": text = _actor_name(event.actor) + " · " + Rules.ACTIONS[event.id].name + " 시작"
			"ready": text = _actor_name(event.actor) + " · 회수 종료 / 다음 선택"
			"moved": text = "%s · 이동 (%d,%d)" % [_actor_name(event.actor), event.position.x, event.position.y]
			"effect":
				var name_text: String = Rules.ACTIONS[event.id].name
				if event.get("attack", false):
					text = "%s · %s · %s · 피해%d" % [_actor_name(event.actor), name_text, "명중" if event.hit else "빗나감", event.damage]
				else:
					text = _actor_name(event.actor) + " · " + name_text + " 효과 발동"
			"dead": text = _actor_name(event.actor) + " · 전투불능"
			"finished": text = RESULT_NAMES[event.result]
			"cancelled": text = "시험 종료 · 남은 예약 효과 폐기"
			"forced_move": text = "%s · 밀치기·후퇴 결과 (%d,%d)" % [_actor_name(event.actor), event.position.x, event.position.y]
			"movement_conflict": text = _actor_name(event.actor) + " · 상충하는 강제 이동 생략"
		if not text.is_empty():
			_history.append("T %.3f · %s" % [float(event.time_ticks)/Rules.TIME_SCALE, text])
	_event_cursor = events.size()

func _enter_command() -> bool:
	if _input_locked:
		return false
	_input_locked = true
	_unlock_input.call_deferred()
	return true

func _unlock_input() -> void:
	_input_locked = false
	if is_inside_tree():
		refresh_view()

func _on_scenario_selected(index: int) -> void:
	if _input_locked:
		scenario_picker.select(scenario_index)
	else:
		restart_scenario(index)

func _exit_tree() -> void:
	clock.cancel_battle()

func _reason(value: String) -> String:
	return REASONS.get(value, value)

func _actor_name(index: int) -> String:
	return "도원" if index == 0 else "적"

func _direction(value: Vector2i) -> String:
	return DIRECTION_NAMES[Rules.DIRECTIONS.find(value)]

func _cells_text(cells: Array) -> String:
	if cells.is_empty():
		return "공격 칸 없음"
	var labels: PackedStringArray = []
	for point in cells:
		labels.append("(%d,%d)" % [point.x, point.y])
	return " ".join(labels)

func _label(parent: Node, value: String) -> Label:
	var result = Label.new()
	result.text = value
	parent.add_child(result)
	return result

func _button(parent: Node, value: String, callback: Callable) -> Button:
	var result = Button.new()
	result.text = value
	result.custom_minimum_size.y = 38
	result.pressed.connect(callback)
	parent.add_child(result)
	return result
